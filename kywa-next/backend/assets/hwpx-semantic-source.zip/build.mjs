import {build} from 'esbuild';
import {fileURLToPath} from 'node:url';
process.chdir(fileURLToPath(new URL('.',import.meta.url)));
await build({absWorkingDir:fileURLToPath(new URL('.',import.meta.url)),entryPoints:['entry.ts'],bundle:true,platform:'node',target:'node22',format:'cjs',outfile:'../../backend/assets/hwpx-semantic.cjs',legalComments:'eof'});
