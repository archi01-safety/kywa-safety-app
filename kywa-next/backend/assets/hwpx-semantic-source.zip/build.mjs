import {build} from 'esbuild';
import {fileURLToPath} from 'node:url';
process.chdir(fileURLToPath(new URL('.',import.meta.url)));
await build({entryPoints:['entry.ts'],bundle:true,platform:'node',target:'node22',format:'cjs',outfile:'../../backend/assets/hwpx-semantic.cjs',legalComments:'eof'});
