# Browser port

Upstream: https://github.com/chrisryugj/kordoc

Version 4.16.0, pinned commit `cfd38ae7c594354484ab1bdc116a8af243be6590`. Original LICENSE and NOTICE are retained in the distribution.

`scripts/port-kordoc.mjs` reproduces modifications from `.cache/kordoc-<commit>/src`. Files under `src/browser` are independent browser adapters and are not overwritten by the port script.

The port replaces filesystem/network model loading with integrity-checked same-origin model caching, Node ONNX with ONNX Runtime Web WASM, native image manipulation/PDF rendering with browser canvas/PDF.js, Node compression with fflate, and Node Buffer with the browser package. It disables the unavailable formula OCR service, keeps page limits and partial OCR errors, and releases page-local PDF resources.

Additional layout hooks run before document-level table merging and page cleanup. `layout-observer.ts` exposes native PDF pages and OCR coordinates to the app. Image-region records carry their source operator index so the app can decode original image objects without accidentally copying overlaid text from a rendered page crop. Native layout preservation retains logos as images and avoids unnecessary OCR of those logos; scanned/invalid text pages still receive OCR.

`src/fidelity` in the application uses the upstream table geometry and HWPX header, style, picture and section helpers. It writes editable positioned text boxes and native table cells rather than passing font/position information through Markdown. `src/converter.ts` keeps the upstream Markdown generator for content-oriented output and unsupported-layout fallback. No official-document wording correction is applied.

Actual Hancom 2020 verification found that font-space handling and fontLineHeight must also be applied to the base paragraph styles. Table line spacing uses source baselines and measured font extents; source font sizes use 100 HWPUNIT per PDF point. Original font availability remains a requirement of the editing computer, and variable-font rendering can differ in older Hancom versions.

The header compatibility target is corrected from `HWP2018` to `HWP201X`, the value emitted by Hancom 2020. Repeated actual opens of the former could import legacy layout flags, increasing font line height and table size. The corrected target survived open/resave/reopen with the intended empty compatibility flag set and stable table dimensions.

The port also captures `TABLE_GEOMETRIES` before semantic row trimming/joining, propagating snapshots through adjacent-table merges. The fidelity adapter walks nested grids inside-out, assigning text to the smallest containing cell and validating exact row/column coverage before generating XML. Cells are serialized in column order. Native cell fills and individual edge styles come from the PDF; spanning strokes that already form cell borders are not emitted again as shapes.

Institution font aliases include H2hdrM → HY헤드라인M and Human Myeongjo. Verified anonymous Type3 outlines are identified through SHA-256 fingerprints in the application, without distributing font programs or glyph paths. HFT and TTF versions of a family get distinct style IDs; HFT language references reproduce the inspected HWP's Latin/symbol partners. Source font metrics and baseline deltas control line positioning. Hancom paragraph left margins use twice-HWPUNIT (even raw values). Cells retain explicit PDF line breaks using SQUEEZE to avoid extra rows from small font-width differences.

The browser adapter decodes original image objects, records visible text paint and rectangular clipping, deduplicates shadow text, and converts non-text vector paths into editable polygons. Full-page scanned images are not used as editable-document substitutes. A large decorative image is retained only when it has a blank central writing area and the page has independent native text. PNG clipping uses intrinsic image dimensions so logos are not truncated by the generator's default body-width cap. Complex clipping, curves and mixed formatting can still differ from the original.


## 2026-10-20 한글 2014 패키지 호환 통합

`src/browser/hwpx-package.ts`의 버전·설정 파일 생성과 manifest의 settings 항목을 유지한다. `scripts/port-kordoc.mjs`는 gen-header의 재노출, settings 항목, header spine의 linear 설정을 보존한다. 일반 본문을 글상자로 바꾸는 수정은 호환성 요건이 아니다. 앱은 PDF와 KYWA 출력 모두에서 settings 연결을 검증한다. v0.3.13의 실제 한글 검증은 2020이며, 2014 검증 근거는 가져온 2026-10-16 기록이다.
