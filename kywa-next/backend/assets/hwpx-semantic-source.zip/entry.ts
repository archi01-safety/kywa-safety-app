// Semantic KYWA report adapter. No PDF coordinates, text boxes or 1x1 positioning tables.
import JSZip from 'jszip';
import {DOMParser} from '@xmldom/xmldom';
import {generateContainerXml,generateHeaderXml,generateManifest,generateVersionXml,generateSettingsXml} from './vendor/kordoc/src/hwpx/gen-header';
import {generateSecPr} from './vendor/kordoc/src/hwpx/gen-section';
import {escapeTextXml,resolveTheme,paraPr,pageNumCtrl,NS_SECTION,NS_PARA,NS_CORE} from './vendor/kordoc/src/hwpx/gen-ids';
import {StyleRegistry} from './vendor/kordoc/src/hwpx/style-registry';
import {ImageRegistry,probeImageSize} from './vendor/kordoc/src/hwpx/gen-image';
import {validateHwpx} from './vendor/kordoc/src/validate';

type Model = {facts:any;overview:string;priorities:string[];details:any[]};
type Input = {model:Model;photos:Record<string,string>;photoKeys:Array<[string,string]>;chart:string;colors:Record<string,string>};
const hu=(v:number)=>Math.round(v*100);
const margin=(tag:string,l=0,r=0,t=0,b=0)=>`<hp:${tag} left="${hu(l)}" right="${hu(r)}" top="${hu(t)}" bottom="${hu(b)}"/>`;
const size=(w:number,h:number)=>`<hp:sz width="${hu(w)}" widthRelTo="ABSOLUTE" height="${hu(h)}" heightRelTo="ABSOLUTE" protect="0"/>`;
const inline='<hp:pos treatAsChar="1" affectLSpacing="1" flowWithText="1" allowOverlap="0" holdAnchorAndSO="0" vertRelTo="PARA" horzRelTo="COLUMN" vertAlign="TOP" horzAlign="LEFT" vertOffset="0" horzOffset="0"/>';

export async function generate(input:Input){
 const m=input.model,f=m.facts;
 if(!m.details.length||m.details.length!==f.total)throw Error('Report count mismatch');
 const assets=new Map(Object.entries(input.photos).map(([key,data])=>[key,new Uint8Array(Buffer.from(data,'base64'))]));
 assets.set('category-chart.png',new Uint8Array(Buffer.from(input.chart,'base64')));
 const images=new ImageRegistry(assets),styles=new StyleRegistry(11,8,3,['함초롬바탕','함초롬돋움','HY견고딕']);
 let seq=1000000;const next=()=>++seq;
 const paraStyles:string[]=[],paraIds=new Map<string,number>();
 function ps(align='LEFT',before=0,after=0,keep=false,line=130){
  const key=[align,before,after,keep,line].join('|');if(paraIds.has(key))return paraIds.get(key)!;
  const id=8+paraStyles.length;
  paraStyles.push(paraPr(id,{align,spaceBefore:hu(before)*2,spaceAfter:hu(after)*2,keepWord:false,keepWithNext:keep,widowOrphan:true})
   .replace('fontLineHeight="0"','fontLineHeight="1"').replace(/<hh:lineSpacing[^>]*\/>/,`<hh:lineSpacing type="PERCENT" value="${line}" unit="HWPUNIT"/>`));
  paraIds.set(key,id);return id;
 }
 function run(text:string,pt=10,bold=false,color='#222222'){
  return `<hp:run charPrIDRef="${styles.char({font:'맑은 고딕',pt,bold,color})}"><hp:t>${escapeTextXml(text)}</hp:t></hp:run>`;
 }
 function p(text:string,o:any={}){return `<hp:p id="${next()}" paraPrIDRef="${ps(o.align,o.before||0,o.after||0,!!o.keep,o.line||130)}" styleIDRef="0" pageBreak="${o.break?1:0}" columnBreak="0" merged="0">${run(text,o.pt||10,!!o.bold,o.color)}</hp:p>`;}
 function object(xml:string,align='LEFT'){return `<hp:p id="${next()}" paraPrIDRef="${ps(align,1,1,false,100)}" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0"><hp:run charPrIDRef="${styles.char({font:'맑은 고딕',pt:1})}">${xml}<hp:t/></hp:run></hp:p>`;}
 function picture(key:string,maxW:number,maxH:number){
  const bytes=assets.get(key);if(!bytes)throw Error('Missing photo');
  const d=probeImageSize(bytes);if(!d||!d.w||!d.h)throw Error('Invalid image');
  const scale=Math.min(maxW/d.w,maxH/d.h),part=images.take(key)!;
  part.wHU=hu(d.w*scale);part.hHU=hu(d.h*scale);
  const w=d.w*75,h=d.h*75;
  return images.inlinePicXml(part).replace('affectLSpacing="0"','affectLSpacing="1"')
   .replace(/<hp:orgSz[^>]*\/>/,`<hp:orgSz width="${w}" height="${h}"/>`)
   .replace(/<hp:imgRect>[\s\S]*?<\/hp:imgRect>/,`<hp:imgRect><hc:pt0 x="0" y="0"/><hc:pt1 x="${w}" y="0"/><hc:pt2 x="${w}" y="${h}"/><hc:pt3 x="0" y="${h}"/></hp:imgRect>`)
   .replace(/<hp:imgClip[^>]*\/>/,`<hp:imgClip left="0" right="${w}" top="0" bottom="${h}"/>`)
   .replace(/<hp:imgDim[^>]*\/>/,`<hp:imgDim dimwidth="${w}" dimheight="${h}"/>`)
   .replace(/<hc:scaMatrix[^>]*\/>/,`<hc:scaMatrix e1="${part.wHU/w}" e2="0" e3="0" e4="0" e5="${part.hHU/h}" e6="0"/>`);
 }
 type Cell={xml:string;width?:number};
 function table(rows:Cell[][],heights:number[],widths:number[],header=true,border=2){
  const n=rows.length,c=widths.length;if(n===1&&c===1)throw Error('Positioning table forbidden');
  const body=rows.map((row,r)=>`<hp:tr>${row.map((cell,k)=>`<hp:tc name="" header="${header&&r===0?1:0}" hasMargin="1" protect="0" editable="1" dirty="0" borderFillIDRef="${border}"><hp:subList id="" textDirection="HORIZONTAL" lineWrap="BREAK" vertAlign="CENTER" linkListIDRef="0" linkListNextIDRef="0" textWidth="0" textHeight="0" hasTextRef="0" hasNumRef="0">${cell.xml}</hp:subList><hp:cellAddr colAddr="${k}" rowAddr="${r}"/><hp:cellSpan colSpan="1" rowSpan="1"/><hp:cellSz width="${hu(widths[k])}" height="${hu(heights[r])}"/>${margin('cellMargin',3,3,1,1)}</hp:tc>`).join('')}</hp:tr>`).join('');
  return object(`<hp:tbl id="${next()}" zOrder="1" numberingType="TABLE" textWrap="TOP_AND_BOTTOM" textFlow="BOTH_SIDES" lock="0" pageBreak="NONE" repeatHeader="${header?1:0}" rowCnt="${n}" colCnt="${c}" cellSpacing="0" borderFillIDRef="${border}" noShading="0">${size(widths.reduce((a,b)=>a+b,0),heights.reduce((a,b)=>a+b,0))}${inline}${margin('outMargin',0,0,2,3)}${margin('inMargin')}${body}</hp:tbl>`);
 }
 function textTable(rows:string[][],height=22,pt=10){const widths=rows[0].map(()=>523/rows[0].length);return table(rows.map((row,i)=>row.map(text=>({xml:p(text,{pt,bold:i===0,align:'CENTER',line:110})}))),rows.map(()=>height),widths);}
 const heading=(text:string)=>p(text,{pt:12,bold:true,before:10,after:4,keep:true});
 let body=m.facts.title.split('\n').map((t:string)=>p(t,{pt:18,bold:true,align:'CENTER',after:3})).join('');
 body+=heading('1. 위험성평가 개요');
 body+=p('평가 기간  '+f.period,{after:2})+p('평가 대상  '+f.facilities.join(', '),{after:4});
 body+=textTable([['총 평가','개선 완료','미완료'],[`${f.total}건`,`${f.complete}건`,`${f.incomplete}건`]],24,11);
 body+=heading('2. 최초 위험등급별 현황');
 const grades=['매우 높음','높음','약간 높음','보통','낮음','매우 낮음',...Object.keys(f.grades).filter(x=>!['매우 높음','높음','약간 높음','보통','낮음','매우 낮음'].includes(x))];
 body+=textTable([grades,grades.map(g=>`${f.grades[g]||0}건`)],22,9.5);
 body+=heading('3. 유해위험요인 분류');
 const categories=Object.entries(f.categories) as Array<[string,number]>;
 const legend=(items:Array<[string,number]>)=>items.map(([name,count])=>p(`■ ${name}  ${count}건 (${Math.round(count/f.total*100)}%)`,{pt:9,color:input.colors[name]||'#757575',after:3})).join('');
 const legends=categories.length>6?[legend(categories.slice(0,6)),legend(categories.slice(6))]:[legend(categories)];
 body+=table([[{xml:object(picture('category-chart.png',120,120),'CENTER')},...legends.map(xml=>({xml}))]],[126],legends.length===1?[155,368]:[155,184,184],false,1);
 body+=heading('4. 총평 및 우선 조치사항')+p(m.overview,{after:4});
 for(const t of m.priorities)body+=p('• '+t,{before:2});
 body+=p('상기 위험요인의 개선조치와 이행 여부를 지속 확인하여야 함.  끝.',{before:6})+p('붙임  위험성평가 세부 결과.  끝.',{before:10});
 for(let i=0;i<m.details.length;i++){
  const d=m.details[i],b=d.before,a=d.after,s=d.summary;
  if(i%2===0)body+=p('붙임  위험성평가 세부 결과',{break:true,pt:14,bold:true,after:8,keep:true});
  body+=p(`${String(i+1).padStart(2,'0')}  ${b.location}`,{pt:11,bold:true,before:i%2?12:0,after:3,keep:true});
  body+=p(`${d.facility} · ${d.department} · ${b.category} · ${d.status}`,{pt:9.5,after:3,keep:true});
  body+=textTable([['최초',`빈도 ${b.p}`,`강도 ${b.s}`,`${b.score}점`,b.grade],a?['개선 후',`빈도 ${a.p}`,`강도 ${a.s}`,`${a.score}점`,a.grade]:['개선 후','미기록','','','']],18,9.5);
  for(const [label,key] of [['위험상황','scenario'],['감소대책','solution'],['실제 조치','action'],['관련근거','law']])body+=p(`${label}  ${s[key]||'기록 없음'}`,{pt:9.5,before:2,line:125});
  const keys=input.photoKeys[i];
  body+=table([[{xml:p('개선 전',{pt:9,align:'CENTER'})},{xml:p('개선 후',{pt:9,align:'CENTER'})}],keys.map(key=>({xml:key?object(picture(key,249,94),'CENTER'):p('사진 없음',{pt:9,align:'CENTER'})}))],[15,98],[261.5,261.5],true);
 }
 let sec=generateSecPr(null).replace(/<hp:margin[^>]*\/>/,'<hp:margin header="0" footer="1800" gutter="0" left="3600" right="3600" top="3600" bottom="3000"/>')+pageNumCtrl();
 body=body.replace(/(<hp:run[^>]*>)/,`$1${sec}`);
 const section=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><hs:sec xmlns:hs="${NS_SECTION}" xmlns:hp="${NS_PARA}" xmlns:hc="${NS_CORE}">${body}</hs:sec>`;
 let header=generateHeaderXml(resolveTheme(),null,[],[],styles.charPrXmls,[],styles.extraFonts);
 header=header.replace(/<hh:paraProperties itemCnt="(\d+)">/,(_,n)=>`<hh:paraProperties itemCnt="${Number(n)+paraStyles.length}">`).replace('</hh:paraProperties>',paraStyles.join('')+'</hh:paraProperties>');
 header=header.replaceAll('useFontSpace="0"','useFontSpace="1"').replaceAll('fontLineHeight="0"','fontLineHeight="1"');
 const zip=new JSZip();zip.file('mimetype','application/hwp+zip',{compression:'STORE'});
 zip.file('version.xml',generateVersionXml());zip.file('settings.xml',generateSettingsXml());zip.file('META-INF/container.xml',generateContainerXml());
 zip.file('Contents/header.xml',header);zip.file('Contents/content.hpf',generateManifest([],images.manifestItems(),'kywa-semantic-report'));
 zip.file('Contents/section0.xml',section);images.parts.forEach(part=>zip.file(part.name,part.data));
 zip.file('Preview/PrvText.txt',[f.title,m.overview,...m.details.map(d=>d.before.location)].join('\n'));
 const bytes=await zip.generateAsync({type:'uint8array',compression:'DEFLATE'});
 const check=await validateHwpx(bytes);if(!check.ok)throw Error('Invalid HWPX package');
 const doc=new DOMParser().parseFromString(section,'text/xml');
 if(doc.getElementsByTagNameNS(NS_PARA,'drawText').length)throw Error('Text box forbidden');
 for(const t of Array.from(doc.getElementsByTagNameNS(NS_PARA,'tbl')))if(t.getAttribute('rowCnt')==='1'&&t.getAttribute('colCnt')==='1')throw Error('Positioning table forbidden');
 return bytes;
}
if(require.main===module){(async()=>{let data='';for await(const c of process.stdin)data+=c;process.stdout.write(await generate(JSON.parse(data)));})().catch(()=>{process.stderr.write('HWPX semantic generation failed\n');process.exitCode=1;});}
