# KYWA 개발·운영 인수인계

## 2026-11-13 — v1.2.0 · 8개 기관 배포 완료 / Actions 종료

운영 소스는 `aa30598da1d019b01742fa8ea378ef6d42feb8fd`이며 [PR #8](https://github.com/archi01-safety/kywa-safety-app/pull/8)에서 공통 운영 브랜치에 병합했다. KYWA·AYF·FoWI·KHIDI·KNPS·KNF·KOHI·CAYF의 해당 SHA Docker 빌드와 **Deploy succeeded | Live**를 확인했다. 기관별 `<기관>/v1.2.0` 태그·releases/ JSON·artifacts/render-deployments.json에 확정 소스/배포 ID/복구 근거를 보관한다. 이후 문서/패키지 커밋은 이 런타임을 변경하지 않는다.

넓은 개선조치 화면은 목록·원본·조치 작성을 독립 스크롤하고 선택 요약을 고정한다. 작은 화면에는 원본 보기 동작을 제공한다. 메뉴 이동 후 초안·선택·조회 조건을 유지하고, 창 크기/짧은 focus 복귀가 목록을 강제로 다시 읽지 않게 했다. 지원기관 헤더는 모바일68px/PC76px로 KYWA 높이에 맞췄다. 상세 원인과 동작은 ACTION-WORKSPACE.ko.md를 따른다.

로컬 백엔드337개(26모듈 독립 프로세스), 프런트단위20개·TypeScript·root/AX webpack 빌드, 합성36건 CUA 독립 스크롤·초안/선택 보존·계획/재평가/완료 저장·7개 지원기관320/390/768/1440px 헤더를 통과했다. 창 크기 연속 변경 전후 목록 API는1회로 동일했다. Windows 같은 프로세스 전체 검사에서 임시 Excel 파일 잠금/잘못된 파일 기술자 오류가 간헐 발생했으며 성공한 독립 검사와 구분해 기록했다. 새 CI는 실행하지 않았다. 로컬 Docker 미설치, 실제 Render8개 빌드/Live 확인은 별도 통과다. 배포 후 별도 업무/데이터 시험은 기존 요청에 따라 생략했다.

사용자 요청으로 `kywa-safety-app`, `kywa-ai-risk-assessment` Actions를 비활성화했다. 원격 산출물70개(약1.4GB)를 삭제하고 두 저장소 잔여0개를 재확인했다. 마지막 운영 CI ZIP2개는 local-data/actions-retirement-20261113/에 비공개 보관했다. main 워크플로17개 및 현재 공통 운영 소스의 워크플로7개/템플릿2개를 제거했다. Render YAML과 검사 코드/수동 명령은 유지한다. 과거 태그 복구나 새 PC 설치 시에도 Actions를 켜거나 워크플로를 되살리지 않는다.

이번에는 Google 시트 구조·값·사진·평가 기준/프롬프트·PIN·환경변수를 변경하지 않았다. 내부 세부 판정은 비활성으로 유지한다. 담당자 사례표의 KYWA 회신은 대기 중이며 다른 기관에 작성을 요청하지 않는다. 소스/AX ZIP은 최신 문서·소스와 `/apps/kywa-safety` 화면으로 갱신하고 인증정보/업무 백업을 제외했다. 실제 AX 등록, 한글2014·실제 진동·Google 호버 미리보기는 기존 미검증 상태다. 다른 PC 이동 직전 최종 비공개 백업은 아직 수행하지 않았다. 아래는 이전 시점 기록이다.

## 2026-11-13 — 8개 기관 v1.1.2 배포·기존 행 정렬 완료

운영 소스는 `329f2f8384c6c94f3cdbe360dfadfbb41b9c024a`다. [PR #7](https://github.com/archi01-safety/kywa-safety-app/pull/7)과 [CI](https://github.com/archi01-safety/kywa-safety-app/actions/runs/43378019457)에서 백엔드 337개, 프런트 단위 15개, 8개 기관 PC/모바일·root/AX 및 Docker 검사를 통과했다. 8개 독립 서비스의 해당 SHA **Deploy succeeded / Live**를 확인했다. 서비스별 배포 ID는 artifacts/render-deployments.json, 고정 버전·설정/프롬프트/시트 구조·복구 근거는 releases/<기관>/v1.1.2.json과 <기관>/v1.1.2 태그를 따른다. 다른 기관까지 한 번에 Blueprint 동기화하지 않았다.

| 기관 | 평가표 | 보존 건수 | 배포 |
|---|---|---:|---|
| KYWA | 20열 | 134건 | Live · v1.1.2 |
| AYF | 18열 | 8건 | Live · v1.1.2 |
| FoWI | 20열 | 131건 | Live · v1.1.2 |
| KHIDI | 20열 | 98건 | Live · v1.1.2 |
| KNPS | 20열 | 187건 | Live · v1.1.2 |
| KNF | 20열 | 13건 | Live · v1.1.2 |
| KOHI | 20열 | 125건 | Live · v1.1.2 |
| CAYF | 20열 | 7건 | Live · v1.1.2 |

운영 전체 파일·GridData·행 식별·숨김 관리·조치이력을 비공개로 백업하고 추가 사진 열을 오른쪽 끝에 확장했다. KHIDI D열 이름, AYF 부서·성명 미수집과 기관별 점수표·색상을 유지했다. 기존 값·사진 링크·행 연결을 대조했고 쓰기 점검은 모두 해제했다. 단답형 기존/신규 행과 Excel을 가운데 정렬하며 긴 설명은 왼쪽 정렬한다. Google native table 확장에 의한 새 행 정렬 덮어쓰기도 같은 요청에서 보정한다. 정렬 외의 기존 서식·값은 보존했다. 공개 자료에는 업무 백업·인증정보를 넣지 않는다.

사진 2+1장·동일 박스 드롭/순서 변경·타원 블러·3장 보고서 배치, 조치예정, 오류 종류/요청번호·로딩 안내, 재시작 후 유효 PIN 세션 복원, HTML 재확인 캐시 보완을 포함한다. 법령 API 8개 출처의 신청·실인증을 완료했고 관련근거 링크를 앱과 3종 출력에 연결했다. 사용 방법은 LAW-USER-GUIDE.ko.md다. 새 기능이 보이지 않는 기존 열린 탭은 한 번 새로고침한다.

AYF 실제 수정 후 조작은 05:17:29~05:26:24 UTC(8분55초, 도구 대기 30초 포함)다. 최초2장·개선1장, 실제 WebP 내용 JPG, 얼굴 블러, 시험 제출·계획·재평가 완료·연속 필터·세션 연장·보고서를 검사했다. 해당 구간 503 및 브라우저 오류/경고는 없었으나 과거 503의 재현·완전 제거를 단정하지 않는다. Excel/PDF는 브라우저 저장본, HWPX는 UI 생성 후 저장 경로를 관찰하지 못해 관리자 API 수신본을 대조했다. 시험 행과 해당 사진3개만 복구 가능하게 정리하고 원래 8건을 보존했다. 이후 재배포에서도 같은 로그인 세션이 유지됨을 확인했다.

한글2020에서 16건9쪽/30건16쪽, 문단·표·사진 교체·저장/재열기·법령 링크·PDF 출력을 확인했다. 한글2014, 실제 휴대폰 진동, Google 시트 호버 미리보기는 미검증이다. 내부 세부 판정은 **DETAILED_RISK_ENABLED=false**다. 사용자가 담당자 확정 사례가 없다고 확인해 합성12사례 검토표(artifacts/risk-score-review-20261113.xlsx)를 제공했다. 합성4사례×3회 점수 일치는 정확도·사진 각도 대조의 대체 검증이 아니다. 전문가 판정과 각도 비교 후 기관별로 활성화를 결정한다.

소스/AX ZIP과 매니페스트를 갱신했다. AX는 /apps/kywa-safety로 빌드하며 실제 AX 등록은 수행하지 않았다. 비공개 근거는 local-data/v11-production/, alignment-copies/, v11-live-post/, v11-native/에 있다. 다른 PC 이동 직전 최종 비공개 백업은 아직 실행하지 않았다. 아래는 이전 시점 기록이다.

## 2026-11-13 14:45 KST — v1.1.1 순차 배포 중

검증 소스 `54a789b27e3fa8e5fc66c19867b2a55b3bcb25d9`는 PR #6에서 운영 브랜치에 병합했고 CI 43370988759의 verify/AX가 모두 성공했다(백엔드 316개, 프런트 단위 15개, 8개 기관 PC/모바일 및 root/AX Docker). 최초 기능 소스 a0b4177의 PR #5/CI도 통과했다. 실제 AYF 브라우저가 예전 HTML을 재사용해 1장 입력창을 표시하는 문제를 발견했고, HTML의 200/304 응답에 재확인을 요구하며 해시 자산만 장기 캐시하도록 보완했다. 기존에 열어 둔 화면은 한 번 새로고침해야 한다.

현재 KYWA는 54a789b Live이며 HTML 200/304 캐시 헤더와 운영 API를 확인했다. AYF는 a0b4177의 실제 운영 시험을 마쳤고 54a789b로 추가 배포 중이다. 다른 6개는 b180b29/19열이며 아직 새 코드나 사진 열을 적용하지 않았다. 운영 시트 확장은 KYWA 19→20열(134건), AYF 17→18열(8건)만 완료했고 원래 값·서식·행 식별·숨김 관리·이력을 비공개 전체 사본 및 로컬 그리드로 보관했다. 완료 기관의 쓰기 점검은 해제됐다. 기관별 실제 현황은 artifacts/render-deployments.json과 비공개 local-data/v11-production/를 대조한다.

AYF 수정 후 시험은 05:17:29~05:26:24 UTC(8분55초, 도구 대기 30초 포함)다. 로그인·연속 필터·홈 초기화·실제 WebP 내용 JPG의 최초2장/개선1장 업로드·얼굴 타원 블러·대표 순서 변경·확인 체크에 따른 제출 차단·시험1건 제출·조치예정·재평가 완료·세션 연장을 수행했다. 이 구간의 503 및 브라우저 오류/경고는 없었다. Excel/PDF는 실제 브라우저 저장 파일을 검사했다. HWPX는 UI 생성/다운로드 동작 뒤 IAB의 저장 경로가 확인되지 않아 관리자 API로 수신한 파일을 검사했다. PDF2쪽/세부 사진3장, Excel사진3장/A3가로/페이지나누기, HWPX사진3열·공식 링크가 일치했다. 전체 백업 후 표시된 시험 행과 해당 사진3개만 복구 가능하게 정리했고 원래 8건/행 식별을 다시 대조했다. 비공개 근거는 local-data/v11-live-post/다.

법령 API 8개 도메인의 승인·3조항 실조회·잘못된 제목/없는 조항 거부를 모두 확인했다. 한글2020은 16건9쪽/30건16쪽 실제 출력과 문장·표·사진 교체·저장·재열기·공식 링크 열기를 통과했다. 한글2014·실제 모바일 진동·Google 시트 호버 미리보기는 미검증이다. 내부 세부 판정은 사용자에게 확정 사례가 없음을 확인했고 검토표를 제공하기로 했다. 합성4사례×3회 반복 일치는 통과했지만 전문가/사진 각도 대조 전에는 DETAILED_RISK_ENABLED=false를 유지한다.

다음: AYF 패치 확인 후 FoWI→KHIDI→KNPS→KNF→KOHI→CAYF 순으로 백업·짧은 쓰기 점검·마지막 사진 열 확장·54a789b 배포·운영 API 검증. 무료 서버 초기 기동은 유한한 점검에서만 기다리고 절전 방지 주기 호출은 만들지 않는다. 최종 기관별 버전/복구/ZIP/이 문서를 갱신한다. 아래 내용은 이전 시점 기록이다.

## 2026-11-13 — v1.1 구현·검증 중, 운영 배포 전

현재 작업은 `feature/photo-review-v1.1` 브랜치, `kywa-v1.1/kywa-next` 작업 폴더에 있다. 기준 운영 소스는 아래 2026-11-10의 `b180b29`다. 복수 사진(최초 최대 2장/개선 후 1장), 기존 박스 드래그 앤 드롭, 조치예정, 법령 링크, 오류 종류/요청번호, 지연 조회·사진 로딩 안내와 세션 보완을 구현 중이다. 운영 시트의 추가 사진 열 이관이나 새 코드 배포는 아직 수행하지 않았다. 기존 운영 시트는 KYWA 등 19열, AYF 17열이다.

AYF 운영 브라우저 접근 제한은 사용자가 사이트 권한을 변경한 뒤 새 연결에서 해제됐다. 관리자 로그인·필터·상세 사진·텍스트 분석·명시적 시험 1건 제출·재평가/조치 중 저장을 수행했다. 이 구간에서 원래의 503 오류는 재현하지 못했다. 시험 행만 전체 파일 비공개 백업 후 제거했고 기존 평가 8건의 값 보존을 대조했다. 비공개 근거는 `local-data/v11-live-baseline/`에 있으며 공개 저장소에 업로드하지 않는다. 전체 벽시계 구간에는 도구 대기 시간이 포함되므로 이를 정확히 7분의 능동 시험이라고 기록하지 않는다. 보고서 다운로드 UI는 조작했으나 실제 저장 파일의 대조를 완료했다고 표시하지 않는다.

추가 사용자 신고 시 AYF 화면에서는 로그인 만료를 확인했다. Render 로그에는 09:48 종료 후 10:10 재시작이 있으며, 기존 메모리 전용 PIN 세션이 서버 재시작 때 소실되는 구조를 확인했다. 새 구현은 기관/PIN 설정에 묶인 토큰 해시와 절대 만료 시각을 숨김 관리 탭에 보관한다. 한 프로세스/한 인스턴스 운영을 유지하고, 유효 로그인 1시간·명시적 연장·로그아웃 폐기를 보존한다. 이 변경 배포 후 구방식 로그인은 한 번 다시 필요하다. 기존 인증정보나 PIN을 변경하지 않는다.

로컬 백엔드 회귀검사 313개·프런트 단위검사 15개·TypeScript·Next.js webpack 빌드를 통과했다. 이 작업 폴더의 node_modules는 기존 설치의 정션이므로 Turbopack의 프로젝트 밖 파일 제한이 있고, 로컬 빌드는 webpack으로 수행했다. [초안 PR #5](https://github.com/archi01-safety/kywa-safety-app/pull/5)의 c541315에 대한 [CI 43354042458](https://github.com/archi01-safety/kywa-safety-app/actions/runs/43354042458)는 백엔드·정상 npm ci/기본 빌드·PC/모바일·8개 기관·root/AX Docker 검사를 통과했다. 이후 법령명 파서·화면 조회 재사용 보완의 최종 CI는 별도로 확인한다. 실제 한글 편집·출력은 앱 접근 미승인으로 수행하지 못했으며 사용자에게 설정 → Computer use → Any App 및 앱 접근 시 Always allow 경로를 안내했다. 운영 이관, 수정 후 AYF 7분 시험과 8개 기관 배포도 남아 있다.

8개 기관의 기존 비공개 검증 폴더에서 각각 별도 파일 사본으로 오른쪽 사진 열 확장·재실행·기존 기록 보존·최초 2장/개선 1장 실제 Drive 저장/재조회·중복 재시도·계획 저장·재시작 인증·Excel/PDF/HWPX 3장 출력·삭제 후 제출·구버전 구조로 복구 시 신규 기록 보존을 통과했다. 보존 건수는 KYWA 134, AYF 8, FoWI 131, KHIDI 98, KNPS 187, KNF 13, KOHI 125, CAYF 7이다. 운영 원본에는 쓰지 않았고 시험 파일·사진만 휴지통으로 정리했다. 사본의 native table과 basicFilter가 공존할 때 사진 열 확장 요청이 충돌하는 경우를 발견해 표가 필터를 관리하도록 수정했다. 비공개 결과와 출력은 local-data/v11-google/에 있다.

내부 세부 판정은 구현·자동검사 상태이며 `DETAILED_RISK_ENABLED=false`가 기본이다. 대표 사례 반복 및 담당자 판정 대조 없이 실제 정확도 검증이나 운영 활성화를 완료했다고 표시하지 않는다. 법령 API는 사용자 가입·신청 후 인증값을 받았으며 로컬 비공개 auth 파일과 사용자 생성 Render safety-law-api 그룹에 보관한다. 키를 공개 소스에 넣지 않는다. KYWA·AYF·FoWI·KHIDI·KNPS는 승인과 각 실제 기관 출처의 법령 3조항 실인증·제목 불일치/미존재 조항 거부를 통과했다. KNF·KOHI·CAYF의 추가 신청은 10분 간격으로 진행하며 인터넷/모바일과 모든 목록 형식을 선택한다. 출처를 다른 기관으로 위장하지 않는다. Render 연결은 8개 운영 서비스 모두 Link only로 완료했고 시험 서버는 변경하지 않았다. 실제 API 결과를 넣은 3종 출력 링크 필드와 16건/9쪽 PDF 배치를 검사했으나, 실제 한글의 편집·출력·링크 열기는 미검증이다. 새 코드 배포 전이므로 운영 연동 완료라고 표시하지 않는다. 신청·사용 안내는 LAW-API-SETUP.ko.md 및 LAW-USER-GUIDE.ko.md를 따른다.

2026-11-13 13:13 KST 연결 점검: 사용자가 공식 Windows 앱 허용 목록에 Hwp.exe를 직접 추가했고 TOML 문법과 등록값은 정상이다. 현재 CUA는 여전히 한글 접근 미승인을 반환하여 데스크톱 앱 완전 종료/재실행을 안내했다. 이를 앱 검증 완료로 표시하지 않는다. 최종 보완 소스 a0b4177은 push했고 CI 43363581253이 진행 중이다. 상세 재개 지점은 비공개 local-data/v11-checkpoint.json에 기록했다. 다음 법령 신청은 KNF이며 13:21:11 KST 이후 진행한다.

## 2026-11-10 — 8개 기관 Render 조회 성능 개선

2026-11-10에 KYWA·FoWI·KNPS·KNF·KOHI·KHIDI·CAYF·AYF Render에서 `b180b29a5f9cdd39b30aa7d51e06c67584fb29cf`의 Live 상태를 확인했다. 평가표·숨김 관리 정보·행 식별자를 한 번에 읽고, 기존 동기화 절차로 시트 직접 수정·삭제와 미완료 요청을 처리한다. 인증된 목록은 세션·시설 권한·필터별로 메모리에 최대 30초 보관한다. 공개 그래프는 연도별 최근 집계를 먼저 표시하고 수정·제출과 수동 새로고침 시 최신 값을 확인한다. 보고서 생성과 다운로드는 기존의 최신 상태 검사를 거친다.

7개 기관 운영 시트의 읽기 전용 대조에서 일반 조회가 각각 6회에서 1회로 줄었고 목록·확인 항목·집계가 일치했다. KNPS는 신규 행 동기화가 필요해 두 비공개 사본에서 각각 실행했고 104건의 결과가 일치했다. KYWA 운영 주소에서 PC로 그래프를 다섯 번 다시 열었을 때 중앙값은 4.406초에서 0.072초, 집계 요청은 5회에서 0회였다. 8개 운영 주소에서 기관 식별·운영 모드·상태 확인이 일치했고 비로그인 목록 요청은 모두 HTTP 401이었다. 백엔드 271개·프런트 단위 15개와 PC·모바일 회귀검사 및 Docker 빌드가 통과했다. [검증 PR](https://github.com/archi01-safety/kywa-safety-app/pull/3) · [CI 결과](https://github.com/archi01-safety/kywa-safety-app/actions/runs/42755139348).

서비스별 배포 ID는 [Render 배포 기록](artifacts/render-deployments.json)에 있다. 이전 런타임은 `939dbe4`이며 이번 릴리스에는 시트 이관이나 환경변수 변경이 없다.

이전 운영 기록의 기준일은 2026-11-03이다. 이 문서는 새 PC와 새 대화에서 가장 먼저 읽는 현재 상태 문서다. 과거 날짜가 적힌 DEPLOYMENT-NOTES.md 등의 기록과 충돌하면 현재 상태를 실제 서비스에서 확인한다.

## 2026-11-03 FoWI 세션 설정 복구

사용자가 잘못 수정한 FoWI 개별 `SESSION_SECRET`을 전용 난수로 교체·저장했다. 로컬 비공개 값과 저장값의 일치를 값 노출 없이 확인하고 기존 검증 커밋 `939dbe4cdca9967766b6440610cd269100ee4f5b`로 FoWI만 재배포했다. Render 배포 `dep-dbkmald9fdbs73boc17g`의 Deploy succeeded / Live를 확인했다. 기존 로그인은 다시 필요하며 관리자 PIN·Google 기록·다른 기관 설정·런타임 코드는 변경하지 않았다. 사용자 요청에 따라 배포 후 별도 앱 시험은 생략했다.

이번 변경은 Render 환경설정과 운영 기록만의 변경이다. 기존 AX/소스 ZIP에는 비밀값이 없으며 코드가 동일하므로 재생성하지 않았다. 복구 키는 로컬 비공개 auth 폴더에만 보관하고 공개 저장소에 포함하지 않는다.

## 2026-11-03 완료 — KYWA 디자인 보정·AYF 17열·8개 기관 배포

현재 운영 런타임은 `939dbe4cdca9967766b6440610cd269100ee4f5b`다. KYWA·AYF·FoWI·KNPS·KNF·KOHI·KHIDI·CAYF 모두 Render의 **Deploy succeeded / Live**와 해당 커밋을 확인했다. 서비스별 배포 ID는 `artifacts/render-deployments.json`에 기록했다. 이후 문서·패키지 커밋은 운영 런타임을 바꾸지 않는다.

- KYWA: 흰 헤더와 어두운 텍스트/버튼, 전체 너비 분석 버튼 복원, 우측 곡선·그라데이션 제거, 활성 AI 재평가 버튼 붉은색. 로고 원본과 기관색 유지.
- 지원기관: 기존 전체 너비 분석 버튼·기관별 색상 유지. 7개 서비스의 개별 `ADMIN_PIN_HASH`는 사용자가 지정한 값으로 저장하고 비공개 원본과 일치 확인했다. 공유 환경 그룹과 KYWA PIN은 변경하지 않았다. 비밀값은 공개하지 않는다.
- AYF: 시설 11개 선택, 부서·성명 수집/필터/관리자/Excel·PDF·HWPX 표시 제거. 운영 평가표는 A:Q **17열**이다. 내부 canonical 19칸 매핑·행 식별·중복 방지·조치이력 유지. 다른 7개 기관 시트 구조는 변경하지 않았다.
- AYF 사본에서 이관 재실행·중복 재시도·직접 수정·삭제 후 제출 검사를 통과했다. 운영 파일 전체 비공개 백업/그리드 스냅샷 후 쓰기 점검 중 19→17열 이관·값/행 식별 대조 완료(활성 평가 0건). 비공개 증빙은 `local-data/ayf-17/production-result.json`, `production-backup.json`, `production-snapshot/`에 있다. 새 호환 프로세스 배포 성공으로 임시 쓰기 점검은 해제됐다.
- [CI 41568061328](https://github.com/archi01-safety/kywa-safety-app/actions/runs/41568061328): 백엔드 268개·프런트 단위 15개·Next 빌드·8개 기관 반응형/테마/브라우저·root/AX Docker·비root·읽기 전용·재시작 검사 통과. 이번 CI 화면 캡처의 별도 수동 육안 검토는 하지 않았다.
- 초기 지원기관 배포의 잘린 PIN 해시는 사용자가 전체 값으로 수정했다. KYWA/KHIDI의 정체된 배포는 취소하고 같은 검증 커밋 재배포로 해결했다. 최종 8개 모두 Live다.
- 사용자 지시에 따라 **배포 후 앱 제출·분석·보고서 등 별도 운영 시험은 생략**했다. Render 배포 완료 확인과 실제 업무 시험을 구분한다.
- 인수인계서·복구 절차·소스 ZIP·AX ZIP을 갱신했다. AX ZIP 경로는 `artifacts/kywa-safety-ax.zip`, 접두 경로는 `/apps/kywa-safety`, 실행은 `python app.py`다. 실제 AX 등록은 수행하지 않았다.

## 2026-11-02 이전 배포 이력

## 당시 상태 — 디자인 검증·8개 Render 배포 완료

2026-11-02 최종 디자인.txt와 UI 콘셉트 이미지를 적용하고 KYWA → AYF → FoWI → KHIDI → KNPS → KNF → KOHI → CAYF에 검증 커밋 `eee38a37f4bcd072f02d5c9d5ce5be19810c7704`를 개별 수동 배포했다. 8개 모두 Render의 **Deploy succeeded / Live**를 확인했다. 서비스별 배포 ID와 이전 커밋은 `artifacts/render-deployments.json`에 기록한다. 이후 문서·패키지 갱신 커밋은 런타임 코드 변경이 아니며 운영은 이 검증 SHA로 고정했다.

KYWA만 #F0145A/#2A8FD8의 네이비·핑크/블루 프리미엄 화면이다. 다른 7개는 기존 레이아웃·크기·문구·배경을 유지하고 지정 메인/서브 컬러만 적용한다. 대비 보정값과 파일 목록은 DESIGN-REVIEW.ko.md 및 artifacts/design-colors.json을 따른다. 기관별 평가·Google 저장소·권한·보고서 업무 로직과 로고 원본은 디자인 단계에서 변경하지 않았다.

[최종 CI 41420384220](https://github.com/archi01-safety/kywa-safety-app/actions/runs/41420384220): 백엔드 264개·프런트 단위 15개·Next 빌드·8개 기관 3개 화면·PC/태블릿/모바일·다크/라이트·root Docker·AX 비root/읽기 전용/재시작 검사 통과. 배포 전 합성 자료의 화면도 검토했다. 사용자의 명시적 지시에 따라 **배포 후에는 Render 완료 상태만 확인하고 제출·사진·보고서 등 별도 운영 시험은 수행하지 않았다.** CI 화면의 체험 환경 배너는 시험 설정이며 운영 환경변수를 바꾸지 않았다.

AX 호환 소스와 등록 ZIP도 준비했다. 실제 AX 등록·Apache/systemd 변경은 수행하지 않았으며 실제 슬러그·할당 포트·환경설정이 있어야 등록할 수 있다. AX-DEPLOYMENT.ko.md와 AX-VERIFICATION.ko.md를 따른다. 현재 승인된 디자인·Render 배포 작업은 완료했다.

## AX 호환 준비 — 실제 플랫폼 등록은 별도

7개 지원기관 배포를 완료한 뒤 사용자 TXT 요청에 따라 AX `/apps/{slug}/` 호환 작업을 진행했다. `app.py`가 PORT/HOST를 받아 실행하며 정적 화면과 서버의 APP_BASE_PATH를 일치시킨다. 데이터·임시 폴더는 소스 밖으로 설정할 수 있다. 백엔드 256개·프런트 단위 15개·접두 경로 빌드를 로컬에서 통과했다. CI 41415666818의 root/AX PC·모바일 및 비root·읽기 전용 Docker·재시작 검사를 모두 통과했다. 최종 ZIP은 AX-VERIFICATION.ko.md 및 artifacts/ax-package.json을 확인한다.

AX 서버/Apache/systemd는 변경하지 않았다. Render는 후속 디자인 배포에서 위 검증 SHA로 갱신했다. AX 등록 시 실제 슬러그·할당 포트·쓰기 폴더·비밀설정이 필요하며 AX-DEPLOYMENT.ko.md를 따른다.

## 작업 위치와 운영 원칙

- 저장소: https://github.com/archi01-safety/kywa-safety-app
- 작업 브랜치: `codex/kywa-next`, 앱 폴더: `kywa-next`, PR: https://github.com/archi01-safety/kywa-safety-app/pull/1
- KYWA: https://kywa-safety.onrender.com/ — 최신 디자인 배포 포함. 현재 SHA는 이 문서의 최신 상태를 따른다.
- Next.js 정적 화면과 FastAPI를 하나의 무료 Docker 웹서비스에서 구동한다. 첫 접속 대기를 수용하며 절전 방지 주기 호출은 추가하지 않는다.
- 기관별 독립 서비스·Google 저장소·평가표·색상을 유지한다. AYF 연결과 7개 지원기관 기능 배포, 후속 8개 디자인 배포를 완료했다. 배포는 검증한 커밋을 기관별로 개별 수행한다.
- 브랜치 최신 코드와 실제 배포는 다를 수 있다. 최신 8개 운영 커밋은 `939dbe4cdca9967766b6440610cd269100ee4f5b`다. 이후 문서 갱신만으로 운영 코드가 바뀌지는 않는다. 아래 기능 배포 기록은 각 작업 당시의 이력이며 현재 배포 판단에는 맨 위 최신 상태를 사용한다.

## 지원기관 개선 — 7개 기관 배포·운영 검증 완료

2026-11-02 AYF → FoWI → KHIDI → KNPS → KNF → KOHI → CAYF 순서로 커밋 `d1d195fd833bc810af8bce34562666edf9d26fe3`를 개별 배포했다. AYF는 전용 시트와 기존 공용 사진 폴더를 연결하여 production으로 전환했다. KYWA 운영 커밋·시트·서비스 설정은 변경하지 않았다. 전체 Blueprint 동기화와 절전 방지 호출은 수행하지 않았다.

| 기관 | 보존한 기존 평가 | 저장 구조 | 배포 및 운영 검증 |
|---|---:|---|---|
| [AYF](https://ayf-safety.onrender.com) | 0건 | 19열 + 숨김 관리 | 완료 |
| [FoWI](https://fowi-safety.onrender.com) | 131건 | 19열 + 숨김 관리 | 완료 |
| [KHIDI](https://khidi-safety.onrender.com) | 98건 | 19열 + 숨김 관리 | 완료 |
| [KNPS](https://knps-safety.onrender.com) | 96건 | 19열 + 숨김 관리 | 완료 |
| [KNF](https://knf-safety.onrender.com) | 13건 | 19열 + 숨김 관리 | 완료 |
| [KOHI](https://kohi-safety.onrender.com) | 125건 | 19열 + 숨김 관리 | 완료 |
| [CAYF](https://cayf-safety.onrender.com) | 6건 | 19열 + 숨김 관리 | 완료 |


기관별 전체 파일을 비공개 공유 드라이브에 백업하고 로컬 값·서식·이력 스냅샷을 남겼다. 기존 6개 기관의 관리 5열을 숨김 `_시스템관리`로 이관했고 KHIDI D열 ‘이름’을 보존했다. 공개 사진 폴더에 업무 백업을 저장하지 않았다. 이전 24열 이관 기록을 근거로 관리 열을 다시 추가하지 않는다.

`experience_version=2`로 개선 입력·홈 초기화·진행 팝업·타원형 머리 블러·수동 로그인 연장·행 삭제/수정·Excel/PDF/문단형 HWPX를 적용한다. `branding.technical_support`로 7개 기관의 공동 기관명·기술지원 안내·Powered by KYWA·개발자정보 팝업을 표시한다. 기관별 점수표·원본 프롬프트 지침·색상·사진 폴더는 유지한다. AYF는 CAYF 지침을 따른다.

[CI 41403837004](https://github.com/archi01-safety/kywa-safety-app/actions/runs/41403837004)의 백엔드·프런트 단위·Next 빌드·KYWA 회귀·7개 기관 PC/모바일 테마 및 동작·Docker 검사를 통과했다. 7개 비공개 사본에서 기존 값/이력 보존, 재이관, 직접 수정/삭제, 잘못된 행 격리, 요청 재시도, 기존 Streamlit 방식 append, 최초/개선 후 사진, 공유 폴더 기관 구분, 조치이력을 검사했다.

7개 운영 서비스에서 실제 AI 탐지/블러→분석→사진·평가 제출→동일 요청 재시도→재평가/조치→재조회와 시설/전체 각각 Excel·PDF·HWPX 총 42개 다운로드를 확인했다. 사진 바이트·공식 Drive 링크·Roboto 서식·파일명 및 기록 일치를 대조했다. 로그인 1시간 연장·로그아웃·KOSHA 조회도 통과했다. 시험 행·사진만 정리했고 기존 평가/조치/성명/사진/버전/시각은 보존했다. 삭제된 시험 요청과 감사 이력은 복구 정책상 숨김 관리에 남는다.

실제 한글 2020에서 AYF 5등급/FoWI 6등급 16건 HWPX를 각각 9쪽 PDF로 출력했다. FoWI 일반 문단을 편집·저장·닫기·재열기하여 수정 유지도 확인했다. 표/사진 편집 경로는 기존 공통 생성기의 KYWA 검증과 함께 적용한다. KHIDI Excel의 실제 인쇄 화면에서 활성 시트·한 부씩·A3 가로·보통 여백·모든 열 한 페이지를 확인했다.

미검증 범위: 저장된 브라우저 권한이 AYF 운영 화면과 Google Sheets를 차단하여 AYF 운영 UI 직접 조작 및 시트 호버 미리보기는 완료로 표시하지 않는다. 7개 기관의 PC/모바일 화면 검증은 승인된 CI에서 수행했고, 접근 가능한 운영 사이트는 기관명·지원 안내·팝업·홈 초기화를 추가 확인했다. 한글 2014·실제 모바일 진동·다른 PC 프린터 설정은 별도 확인이 필요하다. 기존 Streamlit 웹 화면 자체가 아닌 기존 append 저장 방식으로 호환을 검사했다.

현재 검증 요약은 `artifacts/partner-rollout-verification.json`, 실제 Render 배포는 `artifacts/render-deployments.json`에 기록한다. 비공개 근거는 `local-data/partner-rollout/`의 targets/extended, production/*/cloud-backup·migration·baseline·live, documents/native-verification, ci-ui에 보관하며 GitHub에 올리지 않는다. 운영·복구 절차는 PARTNER-ROLLOUT.ko.md를 따른다.

## 사진·저장 속도·다운로드 개선 — KYWA 배포 완료

새 사진의 머리 윤곽 타원 블러, 시설·한국 시각 파일명, Drive 공식 링크, 저장 작업 내 조회 재사용과 스레드별 Google 클라이언트, 서버 확정 보고서 파일명을 구현했다. 2026-11-02 이전 사진/링크는 변경하지 않는다. 최종 CI [41390527355](https://github.com/archi01-safety/kywa-safety-app/actions/runs/41390527355)의 백엔드 224개·프런트 단위 15개·PC/모바일·기관 테마·Docker 검사를 통과하고 KYWA만 배포했다. 사본에서 최초/개선 후 사진·동일 요청 재사용·같은 초의 별도 사진·공식 클릭 링크·Roboto 10pt·처리 이미지 바이트 일치를 확인했고, 행 삭제/직접 수정/잘못된 행 격리 후 신규 제출도 재검증했다. 운영에서 실제 얼굴 블러→분석→최초/개선 후 사진 저장, 사진 바이트·공식 링크 일치, 동일 요청 재사용, 시설/전체 조회의 6개 보고서 파일명과 재다운로드 고정을 확인했다. 시험 행 1건과 사진 2개만 정리하고 기존 136건의 평가·조치·사진 링크·성명·버전·시각 보존을 대조했다. 운영 배포 직후 사진 제출 1회는 14.54초였으며 사본 반복 측정과 실행 환경이 다르다. docs.google.com 브라우저 접근 제한으로 호버 미리보기는 미검증이다. 자세한 기준과 성능 비교는 [PHOTO-STORAGE.ko.md](PHOTO-STORAGE.ko.md)를 따른다.

## 시트 직접 삭제·수정 지원 — 배포·운영 검증 완료

2026-11-02 후속 작업. 행 삭제 후 과거 행 연결 오류가 신규 제출까지 막던 문제를 수정했다. KYWA 운영 시트를 전체 백업하고 135건에 Google 행 식별정보를 연결했으며, 일치하는 실제 행이 없는 관리 기록 4건은 삭제 상태로 보관했다. 평가 탭 19열·기존 값·기존 조치이력 3건은 변경하지 않았다. KYWA만 새 코드를 배포했으며 실제 제출·중복 재시도·직접 수치 수정·중간 행 삭제·삭제 후 추가·삭제된 요청 재시도 차단·오래된 보고서 차단과 Excel/PDF/HWPX 출력을 확인했다. 시험 행만 정리한 뒤 기존 135건의 ID·최초/개선 평가·사진 링크·성명·처리상태·수정 버전·시각이 모두 그대로임을 대조했다. 신규 앱 쓰기는 재개됐다.

- `backend/sheet_sync.py`, `migrate_row_identity.py`: 안정적인 행 ID, 요청별 중복 확인, 행 추가/요청 원자적 저장, 삭제·직접 수정 감지, 부분 갱신·복구.
- `frontend/app/sheet-issues.tsx`: 행별 확인 사항·현재 기준 적용. 조치 초안 보존 및 최신 보고서 확인 포함.
- CI [41382098619](https://github.com/archi01-safety/kywa-safety-app/actions/runs/41382098619): 백엔드 211개, 프런트 단위 13개, Next 빌드, PC/모바일, 다른 기관 테마 회귀, Docker 통과. PC/모바일의 확인 필요 안내 화면도 시각 검토했다. 로컬 브라우저 실행은 완료되지 않아 승인된 CI에서 검사했다.
- 공유 드라이브 사본: 첫/중간/마지막/전체 행 삭제, 마지막 A:S 지우기 후 추가, 직접 수정·15점 높음·잘못된 행 격리·과거 기준 확정·조치 저장·Streamlit 추가 검증 완료.
- 운영 시험 중 제출 1회가 일시적인 HTTP 502로 중단됐다. 숨김 요청 기록과 실제 행에 저장되지 않았음을 확인하고 새 시험을 이어갔으며, 중복 행 없이 완료했다. 테스트용 삭제 기록과 이력은 복구 정책에 따라 내부에 남고 목록·통계·보고서에는 포함되지 않는다.
- 운영 절차·범위·복구는 [SHEET-EDITING.ko.md](SHEET-EDITING.ko.md)를 따른다. 일부 열만 정렬하거나 서로 다른 평가의 셀을 섞지 않는다. 같은 셀을 앱과 시트에서 동시에 수정하지 않는다.

## 이전 개선과 검증 상태(시트 직접 편집 배포 당시)

| 항목 | 현재 상태 |
|---|---|
| 평가표 24/20열 → 19열 이관 | 사본 검사 후 운영 이관 완료. 관리 5열을 숨김 탭으로 이전하고 평가 탭에서 실제 삭제. 앞선 19열 이관 당시 평가 138건·조치이력 3건의 값과 연결 일치. 이후 관리자 삭제를 반영한 현재 활성 평가는 135건이며 위 후속 검증 완료 |
| 시트 삭제·수정 및 신규 제출 | 운영 135건 연결·기존 4건 삭제 상태 분리. 실제 신규 제출/재시도, 직접 수정 15점 높음, 중간 행 삭제 후 새 행 추가, 삭제 요청 재전송 거부 및 3종 보고서 확인 완료 |
| 날짜·서식·표 범위 | 운영 Asia/Seoul·ko_KR, 실제 날짜값·한국어 표시, Roboto 10pt·열별 서식·Form_Responses 표 자동 확장 확인. 실제 신규 시험 값은 `2026. 11. 2 오전 9:59:26`으로 표시 |
| 로그인 연장·문구·전송 버튼 | PC·모바일의 연장·만료·재로그인 초안 복원 검사 통과 |
| Excel | 열 정리·정수·성명 변환·A3 가로·페이지 나누기 보기·사진 앵커 자동 검사 완료. 실제 Excel 인쇄 화면에서 활성 시트·단면·한 부씩·A3 가로·보통 여백·가로 1페이지 설정 확인 |
| 문단형 HWPX | 일반 문단·실제 표·셀 사진 생성 및 1·2·3·16·30건 구조 검사 완료. 한글 2020에서 16건 9쪽·30건 16쪽 출력, 문단·표·사진 편집 → 저장 → 닫기/재열기 → PDF 출력 확인 |
| 보고서 총평 | PDF/HWPX 동일 모델·사진 캐시, 오류 분류와 사실 검증 1회 자동 수정 구현 |
| 백엔드 | 시트 동기화 포함 최신 CI 211개 검사 통과 |
| GitHub/Render | 이번 코드·검사 11개 파일의 로컬/원격 내용 일치 확인. CI 41382098619 통과, KYWA 2db732e 배포 완료. 다른 기관 배포 금지 |
| 앞선 운영 제출·재평가 검사 | 실제 사진 탐지/모자이크 → 분석 → 제출 → Drive 사진 바이트 대조 → 재평가/조치 → 동일 요청 재시도 검사 통과. 시험 기록·조치·사진만 정리하고 기존 138건·3건 보존. 운영 UI에서 문구와 로그인 연장 60:00 확인 |
| 앞선 운영 보고서 검사 | 평창 실제 16건으로 PDF 9쪽·문단형 HWPX·Excel 다운로드 완료. 제목·본문/붙임·제외 항목·HWPX 일반 문단/실제 표·Excel 21열/정수/A3 가로/페이지 나누기 보기 확인 |

## 중요한 결정과 파일

- `backend/organizations/`, `backend/policies/`: 기관별 시설·부서·성명 설정과 서버 점수표. KYWA 6등급 및 15점 '높음' 유지.
- `backend/prompts.py`의 `kywa_prompt`: KYWA 분석 지침. 과거 등급은 새 기준으로 재계산하지 않는다.
- `backend/compact_storage.py`, `migrate_compact.py`, `sheet_format.py`: 평가 탭 A:R + S 제출자 성명, `_시스템관리`에 평가ID·평가기준버전·처리상태·수정버전·시스템데이터 및 요청 관리. 조치이력 탭 유지. 행 직접 삭제·수정은 현재 활성화된 `sheet_sync.py`의 v2 경로로 처리한다. 이전 코드만 단독 롤백하지 않는다. SHEET-EDITING.ko.md를 확인한다.
- `backend/report_model.py`, `report_semantic.py`, `report_layout.py`, `report_jobs.py`: 집계·검증된 총평·PDF/HWPX 공통 모델 및 작업 API.
- `backend/excel_kywa.py`, `chart_colors.py`: KYWA Excel 출력과 고정 분류/시설 색상.
- `tools/hwpx/`: 문단형 HWPX 생성 소스·의존성·라이선스. 실행 파일은 `backend/assets/hwpx-semantic.cjs`.
- `frontend/app/session-clock.tsx`, `page.tsx`: 로그인 만료/연장·초안 보존·기관별 UI.
- 실명 입력은 브라우저 메모리에서만 보유하고 성+초성 변환값만 제출한다. 분석·재평가에 성명 필드를 보내지 않는다.
- 사진 머리 영역 탐지 → 타원 블러 → 처리 사진으로 분석. 실패 시 원본으로 분석/제출을 진행하지 않는다.

## 다음 작업과 검증 범위

1. 지원기관 개선은 완료됐다. 후속 수정은 대상 기관·배포 커밋·현행 시트 구조를 확인한 뒤 진행하고, KYWA 변경은 별도 요청 범위에 따른다.
2. 현재 운영 평가표는 19열이다. 새 PC에서 예전 24열 이관 계획을 보고 재이관하거나 기존 데이터를 되돌리지 않는다. 변경 전 실제 헤더·배포 커밋을 재확인한다.
3. 한글 2020의 문단·표·사진 편집/저장/재열기/PDF 출력은 완료했다. 30건 검사는 배치 검증용 복제 자료로 16쪽을 확인했으며, 실제 30건 총평 정확성 검사와 구분한다. 한글 2014와 실제 모바일 기기의 물리적 진동은 미검증이다.
4. 단면·한 부씩 인쇄는 검증 PC에서 확인했으며 다른 PC의 프린터 드라이버 설정은 다시 확인한다.

## 이번 사진 개선의 비공개 검증 근거

- `local-data/blur-production-backup.json`: 배포 전 운영 파일 전체 값·서식·메타데이터와 같은 공유 드라이브의 전체 사본 위치.
- `local-data/blur-benchmark-before.json`, `blur-benchmark-after.json`, `blur-api-count-before.json`, `blur-api-count-after.json`: 같은 사본·사진의 시간 및 호출 수 비교.
- `local-data/blur-copy-verification.json`, `blur-visual/`: 실제 Google 저장·링크·행 삭제/수정 회귀, 실제 AI 머리 탐지/블러 결과.
- `local-data/blur-remote-verification.json`, `blur-ci-final.json`, `ci-blur/`, `render-blur-live.png`: 공개 소스 일치, CI/PC·모바일 및 Render Live 증거.
- `local-data/live-blur/`: 실제 신규 사진·재평가·제출/중복 재시도·PDF/Excel/HWPX와 최종 기존 기록 대조. 업무 데이터/사진이므로 GitHub 업로드 금지.

## 운영 백업·검증 근거(비공개)

운영 변경 전 공유 드라이브에 파일 전체 사본을 만들고, 로컬 값·서식·표·조치이력 및 숨김 백업 탭을 보관했다. 복구 절차는 KYWA-UPGRADE.ko.md를 따른다. 아래 자료는 GitHub에 업로드하지 않는다.

- `local-data/row-backups/row-identity-20261102-122233.json` 및 같은 접두어 `.cloud.json`: 행 식별정보 적용 직전 전체 백업과 공유 드라이브 사본 위치.
- `local-data/row-sync-production-migration.json`: 135건 연결·4건 삭제 상태·19열·값/기존 이력 보존 결과.
- `local-data/row-sync-copy-verification.json`, `live-row-sync/verification.json`: 사본 및 실제 제출·삭제·수정·재시도·출력 검사. 실제 보고서는 같은 비공개 폴더에 보관.
- `local-data/row-sync-remote-verification.json`, `ci-row-sync/`, `row-sync-ci-success.png`, `render-row-sync-live.png`: 원격 소스 일치, PC/모바일 화면, CI/배포 근거.

- `local-data/production-migration-result.json`, `production-cloud-backup.json`: 운영 이관 결과와 공유 드라이브 백업 위치.
- `local-data/migration-backups/kywa-compact-20261102-095758-e8ca32.json` 및 같은 접두어의 `-latest-values.json`: 이관 직전 전체 백업과 최종 값.
- `local-data/live-followup/verification.json`: 실제 제출·재평가·중복 재시도·시험 자료 정리 증거.
- `local-data/live-followup-reports/verification.json`, `structure-verification.json`: 운영 16건의 PDF/HWPX/Excel 및 구조 검증. 같은 폴더에 실제 출력물을 비공개 보관.
- `local-data/semantic-live/native-validation.json`, 한글 PDF·편집본·Excel 인쇄 화면: 실제 앱 검증 근거.
- `local-data/ci-final/`, `ci-success-nov2.png`, `render-live-nov2.png`: CI 및 배포 확인 화면.

## 새 PC와 이동 전 백업

새 PC 실행 절차는 SETUP.md를 따른다. GitHub에는 소스·설명서·검증 요약을 보관한다. 인증정보와 실제 데이터는 접근이 제한된 별도 저장소로 이전한다. 기존 PC의 `secret`, `local-data` 및 업무 보고서는 공개 저장소에 포함하지 않는다.

이동 직전에는 당시 HEAD·배포 커밋·시트 구조·남은 작업을 다시 확정하고 소스 패키지 해시와 비공개 백업 목록을 기록한다. 지금은 최종 이동 백업을 수행하지 않는다. 대화 전문 대신 결정 이유·검증 근거·미완료 사항을 유지한다.
