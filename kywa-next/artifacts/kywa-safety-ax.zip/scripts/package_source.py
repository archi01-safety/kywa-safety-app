"""Package a source-only allowlist. Never include local credentials, data, or runtimes."""
import hashlib
import json
import zipfile
from pathlib import Path

root=Path(__file__).resolve().parent.parent
out=root/'artifacts'
out.mkdir(exist_ok=True)
patterns=['.gitignore','.dockerignore','.env.example','*.md','app.py','requirements.txt','Dockerfile','render.yaml','pytest.ini','artifacts/render-deployments.json','artifacts/partner-rollout-verification.json','backend/assets/*.cjs','backend/assets/*LICENSE.txt','backend/assets/hwpx-semantic-source.zip','backend/tests/fixtures/*.heic',
          'artifacts/design-colors.json','artifacts/design-scope-audit.json','artifacts/design-verification.json','artifacts/v1.1-verification.json','artifacts/v1.2-verification.json','artifacts/risk-score-review-20261113.xlsx','releases/*/*.json','releases/*.md',
          'backend/prompt_profiles/*.txt','backend/prompt_profiles/*.json','backend/policies/*.json','backend/organizations/*.json','backend/*.py','backend/requirements*','backend/tests/*.py','frontend/app/*.tsx','frontend/app/*.ts','frontend/app/*.css',
          'frontend/public/*.png','frontend/package*.json','frontend/next.config.ts','frontend/next-env.d.ts',
          'frontend/tsconfig.json','frontend/playwright.config.ts','frontend/scripts/*.mjs','frontend/tests/*.ts','frontend/tests/*.mjs','scripts/*.py','scripts/*.ps1','deploy/*.yml']
files=sorted({path for pattern in patterns for path in root.glob(pattern) if path.is_file()})
target=out/'kywa-safety-source.zip'
manifest=[]
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        name='kywa-next/'+path.relative_to(root).as_posix()
        data=path.read_bytes()
        archive.writestr(name,data)
        manifest.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert not any((n.startswith('.github/workflows/') or '/.github/workflows/' in n) and n.endswith(('.yml','.yaml')) for n in archive.namelist())
    assert all('/.env' not in name or name.endswith('/.env.example') for name in archive.namelist())
print(json.dumps({'file':str(target),'files':len(manifest),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
