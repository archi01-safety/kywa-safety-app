import base64
import copy
import hmac
import hashlib
import logging
import secrets
import threading
import time
import uuid
from contextlib import asynccontextmanager, nullcontext
from datetime import date
from urllib.parse import quote

from authlib.integrations.starlette_client import OAuth
from fastapi import FastAPI, Request, HTTPException, UploadFile, File, Form
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from .session_middleware import StableSessionMiddleware
from starlette._utils import get_route_path

from .config import Settings, ROOT
from .domain import (FACILITIES, DEPARTMENTS, CATEGORIES, POLICY, now, risk, digest,
                     SubmitRequest, ActionRequest, StateRequest, ReportRequest, PolicyConfirmRequest, PlanRequest, RotatePhotoRequest)
from .repository import DemoRepository, SheetsRepository, DriveStore, RepositoryError
from .services import Drafts, RateLimiter, AIService, ServiceError, prepare_image, kosha_search
from . import reports
from .pin_auth import PinAuth, PinLocked, SESSION_SECONDS
from .overview import summarize, guide_keywords
from .organization import record_policy, PolicyError
from .submitter_name import display_name
from .branding import palette
from .sheet_schema import SheetSchemaError
from .storage_metrics import submission_metrics, phase
from .filenames import report_filename
from .api_errors import error_response, unexpected, http_code
from .photo_records import before_ids

log = logging.getLogger('kywa')


class BodySizeLimit:
    """Enforce the limit on received bytes as well as the declared Content-Length."""
    def __init__(self, app, max_bytes=11*1024*1024):
        self.app = app
        self.max_bytes = max_bytes

    async def __call__(self, scope, receive, send):
        size = 0
        async def limited_receive():
            nonlocal size
            message = await receive()
            if message['type'] == 'http.request':
                size += len(message.get('body', b''))
                limit = self.max_bytes if get_route_path(scope) == '/api/photos/prepare' else 11*1024*1024
                if size > limit:
                    raise HTTPException(413, '요청 크기 제한을 초과했습니다.')
            return message
        await self.app(scope, limited_receive if scope['type'] == 'http' else receive, send)


def create_app(settings=None, repo=None, drive=None, ai=None):
    cfg = settings or Settings()
    cfg.validate_runtime()
    from .runtime import prepare_runtime
    prepare_runtime(cfg, ROOT / 'frontend' / 'out')
    org = cfg.organization
    FACILITIES, DEPARTMENTS, CATEGORIES = org.facilities, org.departments, org.categories
    POLICY = org.policy.version
    risk = org.policy.risk
    repo = repo or (DemoRepository(cfg.demo_data_path, org) if cfg.demo or cfg.setup else SheetsRepository(cfg))
    drive = drive or DriveStore(cfg)
    ai = ai or AIService(cfg)
    drafts, limits = Drafts(), RateLimiter()
    from .observation_cache import ObservationCache
    from .detailed_risk import ConfirmFacts, VERSION as FACT_VERSION, resolve as resolve_facts, public_item
    from .organization import Policy as AssessmentPolicy
    observations_cache = ObservationCache()
    from .law_links import LawLinks, references
    law_links = LawLinks(cfg.law_api_oc,referer=cfg.app_base_url)
    overview_cache = {}
    draft_epochs = {}
    epoch_lock = threading.Lock()
    pin_auth = PinAuth(cfg.admin_pin_hash) if cfg.auth_mode == 'pin' else None
    if pin_auth and org.enhanced and not cfg.demo and isinstance(repo,SheetsRepository):
        from .persistent_pin import PersistentPinAuth,SheetsPinSessions
        pin_auth=PersistentPinAuth(cfg.admin_pin_hash,SheetsPinSessions(repo,cfg.admin_pin_hash))
    expensive, memory_lock = threading.BoundedSemaphore(2), threading.BoundedSemaphore(1)
    from .report_jobs import ReportJobs, MIMES
    report_jobs = ReportJobs(ai,drive,org,memory_lock,law_links)
    app = FastAPI(title=f'{org.short_name} Safety API', root_path=cfg.app_base_path, docs_url='/api/docs' if cfg.demo else None, redoc_url=None,
                  openapi_url='/api/openapi.json' if cfg.demo else None)
    app.state.repo, app.state.drafts, app.state.settings = repo, drafts, cfg
    app.state.pin_auth = pin_auth
    app.state.storage_pause_until = 0.0
    cookie_name = 'kywa_session' + ('_' + hashlib.sha256(cfg.app_base_path.encode()).hexdigest()[:12] if cfg.app_base_path else '')
    app.add_middleware(StableSessionMiddleware, secret_key=cfg.session_secret, session_cookie=cookie_name,
                       max_age=SESSION_SECONDS if pin_auth and not org.enhanced else 28800, path=cfg.app_base_path or '/', same_site='lax', https_only=cfg.app_base_url.startswith('https://'))
    app.add_middleware(BodySizeLimit, max_bytes=(21 if org.enhanced else 11)*1024*1024)
    oauth = OAuth()
    oauth.register(name='google', client_id=cfg.google_client_id, client_secret=cfg.google_client_secret,
                   server_metadata_url='https://accounts.google.com/.well-known/openid-configuration',
                   client_kwargs={'scope': 'openid email profile', 'code_challenge_method': 'S256'})

    @app.middleware('http')
    async def security_headers(request, call_next):
        request.state.request_id = uuid.uuid4().hex[:16]
        started = time.monotonic()
        route_path = get_route_path(request.scope)
        if cfg.setup and request.method == 'POST' and not route_path.startswith('/api/analyses/') and route_path not in {
            '/api/auth/pin', '/api/auth/logout', '/api/photos/prepare', '/api/analyses'
        }:
            return JSONResponse({'detail': '기관별 저장소 연결을 준비 중입니다. 분석은 가능하지만 제출·저장은 아직 사용할 수 없습니다.'}, status_code=503)
        if cfg.local_workspace and (not request.client or request.client.host not in {'127.0.0.1', '::1'}):
            return JSONResponse({'detail': '로컬 시험 공간은 이 PC에서만 접근할 수 있습니다.'}, status_code=403)
        # Reject oversized multipart bodies before python-multipart can spool to disk.
        length = request.headers.get('content-length')
        max_body = 21 if org.enhanced and route_path == '/api/photos/prepare' else 11
        if length and (not length.isdigit() or int(length) > max_body * 1024 * 1024):
            return JSONResponse({'detail': '요청 크기 제한을 초과했습니다.'}, status_code=413)
        if request.method == 'POST' and route_path == '/api/photos/prepare' and not length:
            return JSONResponse({'detail': 'Content-Length가 필요합니다.'}, status_code=411)
        response = await call_next(request)
        response.headers['X-Request-ID'] = request.state.request_id
        if response.status_code >= 400 or time.monotonic()-started >= 3:
            # Route templates exclude evaluation IDs; never log query, body or credentials.
            route = getattr(request.scope.get('route'), 'path', 'unmatched')
            log.info('request id=%s method=%s route=%s status=%d elapsed_ms=%d code=%s',
                     request.state.request_id, request.method, route, response.status_code,
                     round((time.monotonic()-started)*1000),getattr(request.state,'error_code',''))
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Referrer-Policy'] = 'same-origin'
        if route_path.startswith('/api/') or route_path == '/healthz':
            response.headers['Cache-Control'] = 'no-store'
        elif (route_path == '/' or route_path.endswith('.html')
              or response.headers.get('content-type', '').startswith('text/html')):
            # Browsers otherwise use Last-Modified heuristic freshness for the app shell.
            # A new deployment must revalidate HTML before loading its hashed bundles.
            response.headers['Cache-Control'] = 'no-cache, max-age=0, must-revalidate'
        elif route_path.startswith('/_next/static/'):
            response.headers['Cache-Control'] = 'public, max-age=31536000, immutable'
        return response

    @app.exception_handler(RequestValidationError)
    async def invalid_request(request, exc):
        # FastAPI's default includes rejected inputs (and potentially raw names).
        # Never serialize or log exc.errors(), exc.body, or the exception text.
        return error_response(request,422,'invalid_input','입력 형식을 확인해 주세요. 성명은 첫 글자와 초성으로 변환하여 제출해야 합니다.')

    @app.exception_handler(HTTPException)
    async def http_error(request, exc):
        response=error_response(request,exc.status_code,http_code(exc),str(exc.detail),exc.status_code in (429,502,503,504))
        for key,value in (exc.headers or {}).items():
            if key.lower() in ('retry-after','www-authenticate'): response.headers[key]=value
        return response

    @app.exception_handler(PolicyError)
    async def invalid_policy_value(request, exc):
        return error_response(request,422,'policy_input',str(exc))

    @app.exception_handler(ServiceError)
    async def service_error(request, exc):
        return error_response(request,getattr(exc,'status',422),getattr(exc,'code','processing_error'),str(exc),getattr(exc,'retryable',False))

    @app.exception_handler(SheetSchemaError)
    @app.exception_handler(RepositoryError)
    async def repository_error(request, exc):
        return error_response(request,409,getattr(exc,'code','storage_conflict'),str(exc))

    @app.exception_handler(Exception)
    async def unexpected_error(request, exc):
        # Provider exceptions may include keys/URLs. Never echo them into HTML or logs.
        log.error('Request failed id=%s type=%s',getattr(request.state,'request_id',''),type(exc).__name__)
        return unexpected(request,exc)

    def session(request):
        if 'owner' not in request.session:
            request.session['owner'] = secrets.token_urlsafe(24)
            request.session['csrf'] = secrets.token_urlsafe(24)
        return request.session['owner']

    def draft_owner(request):
        if not hasattr(request.state, 'draft_owner'):
            owner = session(request)
            with epoch_lock:
                if owner not in draft_epochs:
                    if len(draft_epochs) >= 5000:
                        draft_epochs.pop(next(iter(draft_epochs)))
                    draft_epochs[owner] = secrets.token_urlsafe(24)
                request.state.draft_owner = draft_epochs[owner]
        return request.state.draft_owner

    def mutation(request):
        session(request)
        if request.headers.get('origin', '').rstrip('/') != cfg.app_base_url.rstrip('/'):
            raise HTTPException(403, '허용되지 않은 요청 출처입니다.')
        if not hmac.compare_digest(request.headers.get('x-csrf-token', ''), request.session['csrf']):
            raise HTTPException(403, '세션을 새로고침한 뒤 다시 시도하세요.')

    def user(request, admin=False):
        if pin_auth:
            if not pin_auth.valid(request.session.get('pin_session', '')):
                raise HTTPException(401, '관리자 비밀번호를 입력하세요. 로그인은 1시간 동안 유지됩니다.')
            # Shared PIN does not establish ownership of a Google email address.
            return {'email': 'pin-admin', 'name': '전체 시설 관리자', 'role': 'admin', 'facilities': FACILITIES}
        email = request.session.get('email', '')
        if cfg.demo and email.startswith('demo-'):
            role = 'admin' if email == 'demo-admin@kywa.local' else 'staff'
            account = {'role': role, 'facilities': FACILITIES if role == 'admin' else FACILITIES[:1]}
        else:
            account = cfg.accounts.get(email)
        if not account or account.get('role') not in {'admin', 'staff'}:
            raise HTTPException(401, '승인된 담당자 또는 관리자 계정으로 로그인하세요.')
        if admin and account['role'] != 'admin':
            raise HTTPException(403, '관리자 권한이 필요합니다.')
        return {'email': email, 'name': request.session.get('name', email.split('@')[0]), **account}

    def can_view(account, record):
        return account['role'] == 'admin' or record['facility'] in account.get('facilities', [])

    def get_record(request, record_id, readonly=False):
        account = user(request)
        records,issues=listing_snapshot() if readonly else (repo.snapshot() if hasattr(repo,'snapshot') else (repo.records(),[]))
        issue=next((i for i in issues if i['id']==record_id and can_view(account,i)),None)
        if issue:
            from .sheet_sync import SyncError
            raise SyncError(issue['code'],f"시트 {issue['row']}행 확인 필요: "+' '.join(issue['messages']))
        record = next((r for r in records if r['id'] == record_id), None)
        if not record and hasattr(repo,'deleted_record'):
            deleted=repo.deleted_record(record_id)
            if deleted and can_view(account,deleted):
                from .sheet_sync import SyncError
                raise SyncError('row_deleted','관리자가 시트에서 삭제한 평가입니다. 작성 중인 내용은 유지됩니다.')
        if not record or not can_view(account, record):
            raise HTTPException(404, '평가를 찾을 수 없거나 접근 권한이 없습니다.')
        return record, account

    def public_record(record):
        r = copy.deepcopy(record)
        def strip_internal(value):
            if isinstance(value,dict):
                return {k:strip_internal(v) for k,v in value.items() if not k.startswith('_internal')}
            if isinstance(value,list): return [strip_internal(v) for v in value]
            return value
        r = strip_internal(r)
        for key in list(r):
            if key.startswith('_sheet_'): r.pop(key)
        for key in ('submit_hash', 'operation_id', 'submit_owner', 'legacy_values', '_sheet_row', '_sheet_hash', '_sheet_revision'):
            r.pop(key, None)
        b = r['before']
        b['law_references']=references(r)
        # Preserve the recorded grade, even when today's institution policy differs.
        r['current_risk'] = {key:b[key] for key in ('p','s','score','grade')}
        for target in [r, r.get('after') or {}]:
            target.pop('photo_view_url', None)
            target.pop('photo_view_urls', None)
            fid = target.get('photo_id')
            target['photo_url'] = cfg.public_path(f"/api/assessments/{r['id']}/photos/{fid}") if fid else ''
        r['photo_urls'] = [cfg.public_path(f"/api/assessments/{r['id']}/photos/{fid}") for fid in before_ids(record)]
        r['reassessment_policy'] = None
        try:
            r['reassessment_policy'] = record_policy(r, org).model_dump()
        except ValueError:
            pass
        if not org.department_enabled:
            r.pop('department', None)
        if org.submitter_name.mode == 'disabled':
            r.pop('submitter_name', None)
        else:
            r['submitter_name'] = display_name(r.get('submitter_name'))
        for target in [r['before'], r.get('after') or {}]:
            if 'tone' not in target:
                target['tone'] = next((g.tone for g in org.policy.grades if g.name == target.get('grade')), -1)
                target['urgent'] = next((g.urgent for g in org.policy.grades if g.name == target.get('grade')), False)
        return r

    def listing_snapshot():
        if hasattr(repo, 'listing_snapshot'):
            return repo.listing_snapshot()
        return repo.snapshot() if hasattr(repo, 'snapshot') else (repo.records(), [])

    def filtered(request, facility='', department='', status='', start='', end='', strict=False):
        account = user(request)
        try:
            if start: date.fromisoformat(start)
            if end: date.fromisoformat(end)
            if start and end and start > end: raise ValueError()
        except ValueError:
            raise HTTPException(422, '조회 기간을 확인하세요.')
        def match(r):
            day = r['created_at'][:10]
            return (can_view(account, r) and (not facility or r['facility'] == facility)
                    and (not department or r['department'] == department) and (not status or r['status'] == status)
                    and (not start or day >= start) and (not end or day <= end))
        if strict:
            records, issues = repo.snapshot() if hasattr(repo, 'snapshot') else (repo.records(), [])
        else:
            records, issues = listing_snapshot()
        selected_issues=[i for i in issues if can_view(account,i)
            and (not facility or not i.get('facility') or i['facility']==facility)
            and (not department or not i.get('department') or i['department']==department)
            and (not status or not i.get('status') or i['status']==status)
            and (not start or not i.get('created_at') or i['created_at'][:10]>=start)
            and (not end or not i.get('created_at') or i['created_at'][:10]<=end)]
        request.state.sheet_issues=selected_issues
        if strict and selected_issues:
            from .sheet_sync import SyncError
            lines=', '.join(str(i['row']) for i in selected_issues)
            raise SyncError('report_invalid_rows',f'시트 {lines}행을 먼저 확인하세요. 문제가 있는 평가를 제외한 보고서는 생성하지 않습니다.')
        return [r for r in records if match(r)]

    def guard_ai(request):
        if not limits.allow('ai-total', 60, 3600) or not limits.allow('ai:' + session(request), 10, 600):
            raise HTTPException(429, '분석 요청이 많습니다. 잠시 후 다시 시도하세요.')
        if not expensive.acquire(blocking=False):
            raise HTTPException(429, '다른 분석을 처리 중입니다. 잠시 후 다시 시도하세요.')

    @app.get('/healthz')
    async def health():
        return {'status': 'ok'}

    def auth_status(request):
        remaining=pin_auth.remaining(request.session.get('pin_session','')) if pin_auth else 0
        server_time=time.time()
        return {'active':remaining>0,'server_time':server_time,'expires_at':server_time+remaining if remaining else None,'remaining_seconds':remaining}

    @app.get('/api/auth/session')
    def auth_session(request: Request):
        if not org.enhanced or not pin_auth: raise HTTPException(404)
        return auth_status(request)

    @app.post('/api/auth/extend')
    def auth_extend(request: Request):
        mutation(request)
        if not org.enhanced or not pin_auth: raise HTTPException(404)
        if not pin_auth.extend(request.session.get('pin_session','')):
            raise HTTPException(401,'로그인이 만료되었습니다. 작성 내용은 유지됩니다. 다시 로그인하세요.')
        request.session['renewed_at']=int(time.time())
        return auth_status(request)

    @app.get('/api/bootstrap')
    def bootstrap(request: Request):
        session(request)
        try:
            account = user(request)
        except HTTPException:
            account = None
        return {'mode': cfg.app_env, 'local_workspace': cfg.local_workspace, 'auth_mode': cfg.auth_mode,
                'csrf': request.session['csrf'], 'user': account,
                'auth_session':auth_status(request) if org.enhanced and pin_auth else None,
                'facilities': FACILITIES, 'departments': DEPARTMENTS, 'categories': CATEGORIES,
                'policy': POLICY, 'organization': {**org.model_dump(exclude={'category_guidance', 'prompt_guidance', 'storage', 'source'}),
                    'branding': {**org.branding.model_dump(), 'colors': palette(org.branding.primary),
                                 'secondary_colors': palette(org.branding.secondary)}}, 'report_max_rows': cfg.report_max_rows}

    @app.get('/api/overview')
    def overview(request: Request, year: int | None = None, fresh: bool = False):
        year = int(now()[:4]) if year is None else year
        if not 2000 <= year <= 2100:
            raise HTTPException(422, '조회 연도를 확인하세요.')
        if not limits.allow('overview:' + session(request), 30, 60):
            raise HTTPException(429, '잠시 후 다시 조회하세요.')
        with repo.lock:
            if fresh or time.monotonic() >= overview_cache.get('expires', 0):
                records, _ = listing_snapshot()
                years = {year} | {int(r['created_at'][:4]) for r in records
                                 if str(r.get('created_at', ''))[:4].isdigit()}
                overview_cache['data'] = {y: summarize(records, y, org) for y in years}
                overview_cache['expires'] = time.monotonic() + 30
            return overview_cache['data'].get(year, dict(summarize([], year, org), years=sorted(
                set(overview_cache['data']) | {year}, reverse=True)))

    @app.get('/api/auth/google')
    async def login(request: Request):
        if pin_auth:
            raise HTTPException(404)
        if cfg.demo:
            raise HTTPException(400, '체험 모드에서는 체험 계정을 사용하세요.')
        return await oauth.google.authorize_redirect(request, cfg.public_url('/api/auth/google/callback'))

    @app.get('/api/auth/google/callback')
    async def callback(request: Request):
        if pin_auth:
            raise HTTPException(404)
        try:
            token = await oauth.google.authorize_access_token(request)
            info = token.get('userinfo', {})
            email = info.get('email', '').lower()
            if not info.get('email_verified') or email not in cfg.accounts:
                raise ValueError('Unapproved account')
            request.session.clear()
            session(request)
            request.session.update(email=email, name=info.get('name', email))
            return RedirectResponse(cfg.public_path('/#actions'))
        except Exception:
            return RedirectResponse(cfg.public_path('/?login_error=1'))

    @app.post('/api/auth/demo')
    def demo_login(request: Request, role: str = Form('admin')):
        mutation(request)
        if pin_auth or not cfg.demo or role not in {'admin', 'staff'}:
            raise HTTPException(404)
        request.session['email'] = f'demo-{role}@kywa.local'
        request.session['name'] = '체험 관리자' if role == 'admin' else '중앙 담당자'
        return {'ok': True}

    @app.post('/api/auth/pin')
    def pin_login(request: Request, pin: str = Form(..., max_length=64)):
        mutation(request)
        if not pin_auth:
            raise HTTPException(404)
        try:
            token = pin_auth.login(pin)
        except PinLocked as exc:
            raise HTTPException(429, '비밀번호 입력 오류가 반복되어 잠시 잠겼습니다. 15분 후 다시 시도하세요.',
                                headers={'Retry-After': str(exc.seconds)}) from None
        if not token:
            raise HTTPException(401, '비밀번호가 올바르지 않습니다.')
        pin_auth.revoke(request.session.get('pin_session', ''))
        retained_owner=request.session.get('owner') if org.enhanced else None
        request.session.clear()
        session(request)
        if retained_owner: request.session['owner']=retained_owner
        request.session['pin_session'] = token
        return {'ok': True}

    @app.post('/api/auth/logout')
    def logout(request: Request):
        mutation(request)
        if pin_auth:
            pin_auth.revoke(request.session.get('pin_session', ''))
        request.session.clear()
        return {'ok': True}

    @app.post('/api/photos/prepare')
    def prepare(request: Request, photo: UploadFile = File(...)):
        mutation(request)
        draft_owner(request)
        if not limits.allow('photo:' + session(request), 20, 600):
            raise HTTPException(429, '사진 처리 요청이 많습니다.')
        if not memory_lock.acquire(blocking=False):
            raise HTTPException(429, '다른 사진 또는 보고서를 처리 중입니다. 잠시 후 다시 시도하세요.')
        try:
            raw = photo.file.read((20 if org.enhanced else 10)*1024*1024+1)
            if org.enhanced:
                from .photo_privacy import normalize_photo
                data = normalize_photo(raw)
            else:
                data = prepare_image(raw)
            key = drafts.put(draft_owner(request), {'type': 'photo', 'photo': data, 'source_digest':hashlib.sha256(data).hexdigest()})
            return {'id': key, 'url': cfg.public_path(f'/api/drafts/{key}/photo'),
                    'notice': '자동 얼굴 처리에는 누락이 있을 수 있습니다. 미리보기에서 얼굴·개인정보를 확인하세요.'}
        finally:
            photo.file.close()
            memory_lock.release()

    @app.post('/api/drafts/reset')
    def reset_drafts(request: Request):
        mutation(request)
        previous = draft_owner(request)
        drafts.clear_owner(previous)
        # A new draft owner prevents late analysis replies from reviving cleared drafts.
        with epoch_lock:
            draft_epochs[session(request)] = secrets.token_urlsafe(24)
        return {'ok': True}

    @app.post('/api/photos/{key}/deidentify')
    def deidentify(request: Request, key: str):
        mutation(request)
        if not org.enhanced:
            raise HTTPException(404)
        original = drafts.get(draft_owner(request), key)
        if original.get('invalidated'):
            raise HTTPException(409, '사진이 회전되거나 변경되었습니다. 현재 사진으로 다시 분석하세요.')
        if original['type'] != 'photo':
            raise HTTPException(422, '사진을 다시 선택해 주세요.')
        if original.get('processed_id'):
            saved = drafts.get(draft_owner(request), original['processed_id'])
            return {'id': original['processed_id'], 'url': cfg.public_path(f"/api/drafts/{original['processed_id']}/photo"), 'processed': True}
        draft_owner(request)
        guard_ai(request)
        try:
            from .photo_privacy import deidentify_photo
            with memory_lock:
                data = deidentify_photo(ai, original['photo'])
            processed_id = drafts.put(draft_owner(request), {'type': 'photo', 'photo': data, 'deidentified': True, 'base_photo':original.get('base_photo',original['photo']), 'rotation':original.get('rotation',0), 'source_digest':original.get('source_digest',hashlib.sha256(original['photo']).hexdigest())})
            original['processed_id'] = processed_id
            return {'id': processed_id, 'url': cfg.public_path(f'/api/drafts/{processed_id}/photo'), 'processed': True}
        finally:
            expensive.release()

    @app.post('/api/photos/{key}/rotate')
    def rotate_photo(request: Request, key: str, data: RotatePhotoRequest):
        mutation(request)
        owner = draft_owner(request)
        original = drafts.get(owner, key)
        if original['type'] != 'photo':
            raise HTTPException(422, '회전할 사진을 다시 선택해 주세요.')
        with drafts.lock:
            receipt = original.get('rotation_receipts', {}).get(data.request_id)
            if receipt:
                if receipt['turn'] != data.quarter_turns:
                    raise HTTPException(409, '같은 요청번호로 다른 방향을 적용할 수 없습니다.')
                drafts.get(owner, receipt['id'])
                return {'id':receipt['id'], 'url':cfg.public_path(f"/api/drafts/{receipt['id']}/photo"), 'processed':False}
            if original.get('invalidated'):
                raise HTTPException(409, '이미 변경된 사진입니다. 현재 미리보기에서 회전해 주세요.')
            if not memory_lock.acquire(blocking=False):
                raise HTTPException(429, '다른 사진을 처리 중입니다. 잠시 후 다시 시도하세요.')
            try:
                from .photo_rotation import rotate_still
                base=original.get('base_photo',original['photo'])
                turns=(original.get('rotation',0)+data.quarter_turns)%4
                picture=rotate_still(base,turns)
                target=drafts.put(owner,{'type':'photo','photo':picture,'base_photo':base,'rotation':turns,'source_digest':hashlib.sha256(picture).hexdigest()})
                original.setdefault('rotation_receipts',{})[data.request_id]={'id':target,'turn':data.quarter_turns}
                original['invalidated']=True
                drafts.invalidate_photo(owner,key)
                return {'id':target,'url':cfg.public_path(f'/api/drafts/{target}/photo'),'processed':False}
            finally:
                memory_lock.release()

    @app.get('/api/drafts/{key}/photo')
    def draft_photo(request: Request, key: str):
        draft = drafts.get(draft_owner(request), key)
        if not draft.get('photo'):
            raise HTTPException(404)
        return Response(draft['photo'], media_type='image/jpeg')

    def selected_photo(request, key):
        if not key:
            return None
        draft = drafts.get(draft_owner(request), key)
        if draft.get('invalidated'):
            raise HTTPException(409, '사진이 변경되었습니다. 현재 사진으로 다시 분석하세요.')
        if draft['type'] != 'photo':
            raise HTTPException(422, '사진 초안이 아닙니다.')
        if org.enhanced and not draft.get('deidentified'):
            raise HTTPException(422, '사진의 얼굴 비식별화를 먼저 완료해 주세요.')
        return draft['photo']

    def analysis_reply(request, key, value):
        photo_urls = [cfg.public_path(f'/api/drafts/{photo_key}/photo') for photo_key in value.get('photo_keys',[])]
        if value['type'].endswith('_pending'):
            _,questions,_ = resolve_facts(value['observations'],AssessmentPolicy.model_validate(value['policy_snapshot']))
            return {'draft_id':key,'items':[],'questions':questions,'guide_keywords':[],
                    'photo_urls':photo_urls,'photo_url':photo_urls[0] if photo_urls else ''}
        if value['type']=='after':
            return {'draft_id':key,'revision':value['revision'],**public_item(value['result']),'questions':value.get('questions',[]),
                    'photo_url':cfg.public_path(f'/api/drafts/{key}/photo') if value.get('photo') else ''}
        items=[{**public_item(item),'law_references':references(item)} for item in value['items']]
        return {'draft_id':key,'items':items,'questions':value.get('questions',[]),'guide_keywords':guide_keywords(items),
                'photo_urls':photo_urls,'photo_url':photo_urls[0] if photo_urls else ''}

    def finish_observations(value, answers=()):
        value.setdefault('observation_source',copy.deepcopy(value['observations']))
        observed,questions,items=resolve_facts(value['observation_source'],AssessmentPolicy.model_validate(value['policy_snapshot']),answers,
            optional=True,evidence_text=value.get('text',value.get('description','')))
        value['observations']=observed
        value.setdefault('question_keys',[(q['index'],q['field']) for q in questions])
        value['questions']=[q for q in questions if (q['index'],q['field']) in value['question_keys']]
        items=[law_links.enrich(item) for item in items]
        if value.get('record_id'):
            if len(items)!=1: raise ServiceError('재평가 대상 한 건을 확인하지 못했습니다.',code='ai_result')
            value.update(type='after',result={**items[0],'rationale':'관찰 사실과 확인한 현장 조건을 기준으로 판정한 재평가 초안'})
        else: value.update(type='initial',items=items)

    @app.post('/api/analyses/{key}/confirm')
    def confirm_facts(request:Request,key:str,data:ConfirmFacts):
        mutation(request)
        value=drafts.get(draft_owner(request),key)
        if value.get('invalidated'):
            raise HTTPException(409,'사진이 변경되었습니다. 다시 분석하세요.')
        body_hash=digest(data.model_dump())
        if body_hash in value.get('confirmation_receipts',{}):
            fresh_key=value['confirmation_receipts'][body_hash]
            return analysis_reply(request,fresh_key,drafts.get(draft_owner(request),fresh_key))
        if value.get('superseded') or 'observation_source' not in value:
            raise HTTPException(409,'현재 초안의 추가 확인 대상이 아닙니다. 다시 분석하세요.')
        valid={tuple(pair) for pair in value['question_keys']}
        if any((a.index,a.field) not in valid for a in data.answers):
            raise HTTPException(422,'현재 선택 항목을 확인해 주세요.')
        merged={(a['index'],a['field']):a for a in value.get('fact_answers',[])}
        merged.update({(a.index,a.field):a.model_dump() for a in data.answers})
        from .detailed_risk import FactAnswer
        fresh=copy.deepcopy(value)
        fresh.pop('confirmation_receipts',None)
        fresh['fact_answers']=list(merged.values())
        try: finish_observations(fresh,[FactAnswer(**a) for a in merged.values()])
        except ValueError:
            raise HTTPException(422,'현재 질문의 응답을 확인해 주세요.') from None
        fresh_key=drafts.put(draft_owner(request),fresh)
        value['superseded']=fresh_key
        value.setdefault('confirmation_receipts',{})[body_hash]=fresh_key
        return analysis_reply(request,fresh_key,fresh)

    @app.post('/api/analyses')
    def analyze(request: Request, facility: str = Form(...), department: str = Form(''),
                description: str = Form(''), photo_id: str = Form(''),photo_ids:list[str]=Form([])):
        mutation(request)
        keys = photo_ids or ([photo_id] if photo_id else [])
        if len(keys)>2 or len(set(keys))!=len(keys) or (photo_id and photo_ids and photo_id!=photo_ids[0]):
            raise HTTPException(422,'최초 평가 사진은 서로 다른 사진을 최대 2장 등록하세요.')
        if facility not in FACILITIES or (department not in DEPARTMENTS if org.department_enabled else bool(department)):
            raise HTTPException(422, '시설과 부서를 확인하세요.')
        if len(description) > 6000 or (not description.strip() and not keys):
            raise HTTPException(422, '사진 또는 6,000자 이하의 상황 설명을 입력하세요.')
        photos = [selected_photo(request,key) for key in keys]
        photo = photos[0] if photos else None
        draft_owner(request)
        guard_ai(request)
        try:
            value = {'type':'initial','facility':facility,'department':department,'description':description,
                     'photo':photo,'photos':photos,'photo_keys':keys,'policy_snapshot':org.policy.model_dump()}
            if cfg.detailed_risk_enabled and not cfg.demo and not cfg.setup:
                from .risk_profiles import profile_version
                signatures=[drafts.get(draft_owner(request),key)['source_digest'] for key in keys]
                cache_key=digest([draft_owner(request),org.id,facility,department,description,signatures,
                                  cfg.gemini_model,org.prompt_version,org.policy.model_dump(),profile_version(org.policy)])
                value.update(type='initial_pending',observations=observations_cache.resolve(cache_key,
                    lambda:ai.observe(facility,department,description,photos)))
                if any(item['category'] not in CATEGORIES for item in value['observations']):
                    raise PolicyError('기관 기준에 없는 위험 분류입니다. 다시 분석하세요.')
                finish_observations(value)
                key=drafts.put(draft_owner(request),value)
                return analysis_reply(request,key,value)
            items = ai.analyze(facility, department, description, photos if len(photos)>1 else photo)
            if any(item['category'] not in CATEGORIES for item in items):
                raise PolicyError('기관 기준에 없는 위험 분류입니다. 다시 분석하세요.')
            results = [law_links.enrich({**item, **risk(item['p'], item['s'])}) for item in items]
            value['items']=results
            key = drafts.put(draft_owner(request), value)
            return analysis_reply(request,key,value)
        finally:
            expensive.release()

    def storage_ready():
        if org.enhanced and time.monotonic() < app.state.storage_pause_until:
            raise HTTPException(503, '저장소 정비 중입니다. 입력은 유지됩니다. 잠시 후 다시 전송해 주세요.')

    @app.post('/api/admin/storage-maintenance')
    def storage_maintenance(request: Request, enabled: bool = Form(...)):
        mutation(request)
        user(request, admin=True)
        if not org.enhanced: raise HTTPException(404)
        with repo.lock:
            app.state.storage_pause_until = time.monotonic()+1800 if enabled else 0.0
        return {'paused': enabled, 'lease_seconds': 1800 if enabled else 0}

    @app.post('/api/assessments')
    def submit(request: Request, data: SubmitRequest):
        mutation(request)
        submitter_name = org.name_value(data.submitter_name)
        body_hash = digest(data.model_dump())
        with submission_metrics(org.enhanced), repo.lock, (repo.operation() if hasattr(repo,'operation') and org.enhanced else nullcontext()):
            storage_ready()
            with phase('receipt'):
                previous = repo.receipt(data.request_id) if hasattr(repo,'receipt') else [r for r in repo.records() if r.get('operation_id') == data.request_id]
            if previous:
                if any(r.get('submit_hash') != body_hash or r.get('submit_owner') != digest(session(request)) for r in previous):
                    raise HTTPException(409, '같은 제출번호로 다른 내용을 저장할 수 없습니다.')
                if any(r.get('_sheet_deleted') for r in previous):
                    from .sheet_sync import SyncError
                    raise SyncError('row_deleted','제출 후 관리자가 삭제한 평가입니다. 새 평가가 필요하면 다시 분석해 주세요.')
                return {'ids': [r['id'] for r in previous], 'replayed': True}
            draft = drafts.get(draft_owner(request), data.draft_id)
            if draft.get('superseded') or draft.get('invalidated'):
                raise HTTPException(409,'사진이나 현장 조건이 변경되었습니다. 최신 분석 결과를 사용하세요.')
            if draft['type'] != 'initial':
                raise HTTPException(422)
            indexes = [x.index for x in data.items]
            if len(set(indexes)) != len(indexes) or max(indexes) >= len(draft['items']):
                raise HTTPException(422, '제출 항목을 확인하세요.')
            created_at = now()
            with phase('photo'):
                photo = drive.put_photo(draft['photo'],data.request_id,draft['facility'],created_at) if org.enhanced else {'id':drive.put(draft['photo'],data.request_id),'created_at':created_at}
                stored_photos=[photo] if photo.get('id') else []
                for offset,picture in enumerate(draft.get('photos',[])[1:],start=2):
                    stored_photos.append(drive.put_photo(picture,data.request_id+f'-{offset}',draft['facility'],created_at))
            records = []
            for item in data.items:
                before = dict(draft['items'][item.index])
                before.update(item.model_dump(exclude={'index'}))
                records.append(dict(id=str(uuid.uuid5(uuid.UUID(data.request_id), str(item.index))),
                    created_at=photo['created_at'], facility=draft['facility'], department=draft['department'], before=before,
                    photo_id=photo['id'], after=None, organization_id=org.id, submitter_name=submitter_name,
                    policy_snapshot=draft['policy_snapshot'], prompt_version=org.prompt_version, policy=POLICY, status='접수', revision=1,
                    operation_id=data.request_id, submit_hash=body_hash, submit_owner=digest(session(request))))
            if org.enhanced:
                for record in records:
                    record['photo_view_url']=photo['view_url']
                    record['photo_ids']=[p['id'] for p in stored_photos]
                    record['photo_view_urls']=[p['view_url'] for p in stored_photos]
            repo.apply(records, [])
            overview_cache['expires'] = 0
            return {'ids': [r['id'] for r in records], 'replayed': False}

    @app.get('/api/assessments')
    def listing(request: Request, facility: str = '', department: str = '', status: str = '', start: str = '', end: str = ''):
        records = filtered(request, facility, department, status, start, end)
        records.sort(key=lambda r: r['created_at'], reverse=True)
        return {'items': [public_record(r) for r in records], 'issues':getattr(request.state,'sheet_issues',[])}

    @app.post('/api/assessments/{record_id}/policy')
    def confirm_policy(request: Request, record_id: str, data: PolicyConfirmRequest):
        mutation(request)
        account=user(request,admin=True)
        if not org.enhanced or not hasattr(repo,'confirm_policy'): raise HTTPException(404)
        with repo.lock:
            storage_ready()
            repo.confirm_policy(record_id,data.revision,data.request_id,account['email'])
            overview_cache['expires']=0
        return {'ok':True}

    @app.get('/api/assessments/{record_id}/history')
    def history(request: Request, record_id: str):
        get_record(request, record_id,readonly=True)
        def clean(value):
            if isinstance(value,dict): return {k:clean(v) for k,v in value.items() if k not in {'body_hash','sheet_before','sheet_after'} and not k.startswith('_internal')}
            if isinstance(value,list): return [clean(v) for v in value]
            return value
        return {'items':clean(repo.events(record_id))}

    @app.get('/api/assessments/{record_id}/photos/{file_id}')
    def stored_photo(request: Request, record_id: str, file_id: str):
        record, _ = get_record(request, record_id,readonly=True)
        allowed = {*before_ids(record), (record.get('after') or {}).get('photo_id')}
        if file_id not in allowed:
            allowed.update((e.get('after') or {}).get('photo_id') for e in repo.events(record_id))
        if file_id not in allowed:
            raise HTTPException(404)
        data = drive.get(file_id)
        if not data:
            raise HTTPException(404, '사진을 불러오지 못했습니다.')
        return Response(data, media_type='image/jpeg')

    @app.post('/api/assessments/{record_id}/reassess')
    def reassess(request: Request, record_id: str, text: str = Form(...), photo_id: str = Form('')):
        mutation(request)
        record, _ = get_record(request, record_id)
        if record['status'] == '완료':
            raise HTTPException(409, '완료 건은 다시 열기 후 추가 조치하세요.')
        if not text.strip() or len(text) > 6000:
            raise HTTPException(422, '6,000자 이하의 개선조치 내용을 입력하세요.')
        photo = selected_photo(request, photo_id)
        draft_owner(request)
        guard_ai(request)
        try:
            policy = record_policy(record, org)
            if cfg.detailed_risk_enabled and not cfg.demo and not cfg.setup:
                from .risk_profiles import profile_version
                photo_signature=drafts.get(draft_owner(request),photo_id).get('source_digest','') if photo_id else ''
                cache_key=digest(['after',draft_owner(request),org.id,record['id'],record['revision'],text,photo_signature,cfg.gemini_model,org.prompt_version,profile_version(policy)])
                observed=observations_cache.resolve(cache_key,lambda:ai.observe_after(record,text,photo))
                value=dict(type='after_pending',record_id=record_id,revision=record['revision'],
                    text=text,photo=photo,observations=observed,policy_snapshot=policy.model_dump(),photo_keys=[photo_id] if photo_id else [])
                finish_observations(value)
                key=drafts.put(draft_owner(request),value)
                return analysis_reply(request,key,value)
            result = ai.reassess(record, text, photo)
            result.update(policy.risk(result['p'], result['s']))
            draft_id = drafts.put(draft_owner(request), dict(type='after', record_id=record_id,
                                revision=record['revision'], text=text, photo=photo, photo_keys=[photo_id] if photo_id else [], result=result))
            return {'draft_id': draft_id, 'revision': record['revision'], 'photo_url': cfg.public_path(f'/api/drafts/{draft_id}/photo') if photo else '', **result}
        finally:
            expensive.release()

    @app.post('/api/assessments/{record_id}/actions')
    def action(request: Request, record_id: str, data: ActionRequest):
        mutation(request)
        body_hash = digest(data.model_dump())
        with submission_metrics(org.enhanced), repo.lock, (repo.operation() if hasattr(repo,'operation') and org.enhanced else nullcontext()):
            storage_ready()
            record, account = get_record(request, record_id)
            saved = next((e for e in repo.events(record_id) if e['id'] == data.request_id), None)
            if saved:
                if saved['body_hash'] != body_hash:
                    raise HTTPException(409, '같은 요청번호로 다른 내용을 저장할 수 없습니다.')
                return {'item': public_record(record), 'replayed': True}
            draft = drafts.get(draft_owner(request), data.draft_id)
            if draft.get('superseded') or draft.get('invalidated'):
                raise HTTPException(409,'사진이나 현장 조건이 변경되었습니다. 최신 분석 결과를 사용하세요.')
            if draft['type'] != 'after' or draft['record_id'] != record_id:
                raise HTTPException(422, '다른 평가의 초안입니다.')
            if record['revision'] != data.revision or draft['revision'] != data.revision or record['status'] == '완료':
                raise HTTPException(409, '평가가 변경되었습니다. 목록을 새로고침하고 다시 분석하세요.')
            policy = record_policy(record, org)
            calculated = policy.risk(data.p, data.s)
            created_at = now()
            with phase('photo'):
                photo = drive.put_photo(draft['photo'],data.request_id,record['facility'],created_at,after=True) if org.enhanced else {'id':drive.put(draft['photo'],data.request_id),'created_at':created_at}
            after = dict(**calculated, text=draft['text'],
                         photo_id=photo['id'], actor=account['email'], created_at=photo['created_at'],
                         policy=policy.version, policy_snapshot=policy.model_dump(), prompt_version=org.prompt_version, rationale=draft['result']['rationale'], ai_result=draft['result'])
            if '_internal_risk' in draft['result']:
                after['_internal_risk']=draft['result']['_internal_risk']
            if org.enhanced: after['photo_view_url']=photo['view_url']
            record.update(after=after, status='완료' if data.complete else '조치 중', revision=record['revision']+1)
            event = dict(id=data.request_id, record_id=record_id, at=now(), actor=account['email'],
                         kind='완료' if data.complete else '조치 저장', text=draft['text'], after=after, body_hash=body_hash)
            repo.apply([record], [event])
            overview_cache['expires'] = 0
            return {'item': public_record(record), 'replayed': False}

    @app.post('/api/assessments/{record_id}/plan')
    def plan_action(request:Request,record_id:str,data:PlanRequest):
        mutation(request)
        body_hash=digest(data.model_dump())
        with repo.lock,(repo.operation() if hasattr(repo,'operation') and org.enhanced else nullcontext()):
            storage_ready()
            record,account=get_record(request,record_id)
            saved=next((e for e in repo.events(record_id) if e['id']==data.request_id),None)
            if saved:
                if saved.get('body_hash')!=body_hash:
                    raise HTTPException(409,'같은 요청번호로 다른 계획을 저장할 수 없습니다.')
                return {'item':public_record(record),'replayed':True}
            if record['revision']!=data.revision or record['status']=='완료':
                raise HTTPException(409,'평가가 변경되었거나 완료되었습니다. 초안을 유지한 채 목록을 확인하세요.')
            plan=dict(text=data.text,due_date=data.due_date,created_at=now(),actor=account['email'])
            record.update(plan=plan,status='조치예정',revision=record['revision']+1)
            event=dict(id=data.request_id,record_id=record_id,at=plan['created_at'],actor=account['email'],
                       kind='조치계획',text=data.text,plan=plan,body_hash=body_hash)
            repo.apply([record],[event])
            overview_cache['expires']=0
            return {'item':public_record(record),'replayed':False}

    @app.post('/api/assessments/{record_id}/state')
    def state(request: Request, record_id: str, data: StateRequest):
        mutation(request)
        with repo.lock:
            storage_ready()
            record, account = get_record(request, record_id)
            saved = next((e for e in repo.events(record_id) if e['id'] == data.request_id), None)
            if saved:
                if saved['body_hash'] != digest(data.model_dump()):
                    raise HTTPException(409, '요청 내용이 다릅니다.')
                return {'item': public_record(record)}
            if data.revision != record['revision']:
                raise HTTPException(409, '다른 담당자가 변경했습니다. 새로고침하세요.')
            record.update(status=data.status, revision=record['revision']+1)
            event = dict(id=data.request_id, record_id=record_id, at=now(), actor=account['email'],
                         kind='상태 변경', text=data.status, body_hash=digest(data.model_dump()))
            repo.apply([record], [event])
            overview_cache['expires'] = 0
            return {'item': public_record(record)}

    @app.get('/api/guides')
    def guides(request: Request, keyword: str):
        if not keyword.strip() or len(keyword) > 80:
            raise HTTPException(422, '검색어는 1~80자로 입력하세요.')
        if not limits.allow('guides:' + session(request), 30, 600):
            raise HTTPException(429, '검색 요청이 많습니다.')
        return kosha_search(cfg, keyword.strip())

    @app.get('/api/law-links')
    def laws(request:Request,text:str=''):
        if len(text)>2000: raise HTTPException(422,'관련근거가 너무 깁니다.')
        if not limits.allow('laws:'+session(request),60,600):
            raise HTTPException(429,'법령 확인 요청이 많습니다. 잠시 후 다시 시도하세요.')
        resolved=law_links.resolve_text(text)
        return {'items':resolved['items'],'text':resolved['text'],'configured':bool(cfg.law_api_oc)}

    @app.post('/api/reports')
    def report(request: Request, data: ReportRequest):
        mutation(request)
        user(request, admin=True)
        if data.format == 'hwpx':
            raise HTTPException(422, '한글 보고서는 보고서 생성 작업으로 요청해 주세요.')
        records = filtered(request, strict=True, **data.model_dump(exclude={'format'}))
        if not records:
            raise HTTPException(422, '선택한 조건에 데이터가 없습니다.')
        if len(records) > cfg.report_max_rows:
            raise HTTPException(422, f'한 번에 {cfg.report_max_rows}건까지 출력합니다. 기간이나 시설을 좁혀주세요.')
        if not memory_lock.acquire(blocking=False):
            raise HTTPException(429, '다른 사진 또는 보고서를 처리 중입니다. 잠시 후 다시 시도하세요.')
        try:
            from .law_links import verified_records
            export_records=verified_records(records,law_links) if org.enhanced else records
            output = reports.excel(export_records, drive, org) if data.format == 'xlsx' else reports.pdf(export_records, drive, org)
            if org.enhanced:
                from .report_jobs import signature
                if signature(records)!=signature(filtered(request,strict=True,**data.model_dump(exclude={'format'}))):
                    raise HTTPException(409,'보고서 생성 중 평가가 변경되었습니다. 다시 생성해 주세요.')
            mime = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' if data.format == 'xlsx' else 'application/pdf'
            filename = report_filename(data.facility,data.format,now(),org.short_name) if org.enhanced else f'{org.id}_위험성평가_{now()[:10]}.{data.format}'
            return Response(output, media_type=mime, headers={'Content-Disposition': f"attachment; filename*=UTF-8''{quote(filename)}"})
        finally:
            memory_lock.release()

    @app.post('/api/report-jobs')
    def start_report(request: Request, data: ReportRequest):
        mutation(request)
        user(request, admin=True)
        if not org.enhanced: raise HTTPException(404)
        filters=data.model_dump(exclude={'format'})
        records=filtered(request,strict=True,**filters)
        if not records or len(records)>cfg.report_max_rows:
            raise HTTPException(422,f'선택한 조건에서 1~{cfg.report_max_rows}건을 조회한 뒤 생성하세요.')
        records.sort(key=lambda r:(r['created_at'],r['id']))
        return {'id':report_jobs.start(session(request),records,data.format,filters)}

    @app.get('/api/report-jobs/{job_id}')
    def report_status(request: Request, job_id: str):
        user(request,admin=True)
        job=report_jobs.get(session(request),job_id)
        return {k:job[k] for k in ('state','stage','error_code') if k in job}

    @app.get('/api/report-jobs/{job_id}/download')
    def report_download(request: Request, job_id: str):
        user(request,admin=True)
        job=report_jobs.get(session(request),job_id)
        if job['state']!='complete': raise HTTPException(409,'보고서 생성이 아직 완료되지 않았습니다.')
        from .report_jobs import signature
        if signature(filtered(request,strict=True,**job['filters']))!=job['signature']:
            report_jobs.invalidate(job_id)
            from .sheet_sync import SyncError
            raise SyncError('report_stale','보고서 생성 후 평가가 수정되거나 삭제되었습니다. 최신 목록으로 다시 생성해 주세요.')
        filename=job['filename']
        return Response(job['output'],media_type=MIMES[job['format']],
            headers={'Content-Disposition':f"attachment; filename*=UTF-8''{quote(filename)}"})

    static = ROOT / 'frontend' / 'out'
    if static.exists():
        app.mount('/', StaticFiles(directory=static, html=True), name='frontend')
    else:
        @app.get('/')
        def build_required():
            return {'message': 'frontend에서 npm ci && npm run build 실행 후 서버를 재시작하세요.'}
    return app


app = create_app()
